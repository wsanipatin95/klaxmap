import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
  computed,
  inject,
  signal,
} from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  type FormControl,
  type FormGroup,
} from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';

import type {
  MapaElementoSaveRequest,
  MapaGeomTipo,
  MapaNodo,
  MapaTipoElemento,
} from '../../data-access/mapa.models';
import { MapaConfirmDialogComponent } from '../mapa-confirm-dialog/mapa-confirm-dialog.component';
import type { MapaItemVisualPreview } from '../../utils/mapa-element-visual.utils';
import {
  previewClassForVisual,
  previewImageUrlForVisual,
  previewMaterialFamilyForVisual,
  previewMaterialGlyphForVisual,
  previewShapeClassForVisual,
  previewStyleForVisual,
  resolveMapaTipoVisual,
  showClassPreviewForVisual,
  showMaterialPreviewForVisual,
  showUrlPreviewForVisual,
} from '../../utils/mapa-element-visual.utils';

type EstadoElemento = 'activo' | 'planificado' | 'pendiente_clasificar';

interface CreateElementoFormValue {
  idRedNodoFk: FormControl<number | null>;
  idGeoTipoElementoFk: FormControl<number | null>;
  nombre: FormControl<string>;
  descripcion: FormControl<string>;
  etiqueta: FormControl<string>;
  estado: FormControl<EstadoElemento>;
  visible: FormControl<boolean>;
  ordenDibujo: FormControl<number>;
}

interface TipoAgrupadoVm {
  agrupacion: string;
  tipos: MapaTipoElemento[];
}

interface NodoSelectOption {
  value: number;
  label: string;
}

@Component({
  selector: 'app-mapa-create-element-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DialogModule, SelectModule, MapaConfirmDialogComponent],
  templateUrl: './mapa-create-element-dialog.component.html',
  styleUrl: './mapa-create-element-dialog.component.scss',
})
export class MapaCreateElementDialogComponent {
  private readonly fb = inject(FormBuilder);

  private readonly nodosState = signal<MapaNodo[]>([]);
  private readonly tiposState = signal<MapaTipoElemento[]>([]);

  @Input() set nodos(value: MapaNodo[] | null | undefined) {
    this.nodosState.set(Array.isArray(value) ? value : []);
  }

  @Input() set tipos(value: MapaTipoElemento[] | null | undefined) {
    this.tiposState.set(Array.isArray(value) ? value : []);
    this.ensureTipoSelection();
  }

  @Input() showGeometryPreview = true;

  @Output() submitted = new EventEmitter<MapaElementoSaveRequest>();
  @Output() cancelled = new EventEmitter<void>();
  @Output() requestAdjust = new EventEmitter<{ wkt: string; geomTipo: MapaGeomTipo }>();

  @ViewChild('confirmDialog') confirmDialog?: MapaConfirmDialogComponent;

  readonly visible = signal(false);
  private readonly adjusting = signal(false);
  readonly saving = signal(false);
  readonly error = signal<string | null>(null);
  readonly currentWkt = signal<string | null>(null);
  readonly currentGeomTipo = signal<MapaGeomTipo | null>(null);
  readonly customTitle = signal<string | null>(null);
  readonly submittedAttempt = signal(false);
  readonly nodeLocked = signal(false);

  readonly form: FormGroup<CreateElementoFormValue> = this.fb.group({
    idRedNodoFk: this.fb.control<number | null>(null, Validators.required),
    idGeoTipoElementoFk: this.fb.control<number | null>(null, Validators.required),
    nombre: this.fb.nonNullable.control('', [
      Validators.required,
      Validators.maxLength(180),
    ]),
    descripcion: this.fb.nonNullable.control('', [Validators.maxLength(500)]),
    etiqueta: this.fb.nonNullable.control('', [Validators.maxLength(120)]),
    estado: this.fb.nonNullable.control<EstadoElemento>('activo', Validators.required),
    visible: this.fb.nonNullable.control(true),
    ordenDibujo: this.fb.nonNullable.control(0, [Validators.min(0)]),
  });

  readonly dialogTitle = computed(() => {
    const custom = this.customTitle();
    if (custom) return custom;

    const geom = String(this.currentGeomTipo() || '').toLowerCase();

    if (geom === 'linestring') return 'Nueva ruta';
    if (geom === 'polygon') return 'Nuevo polígono';
    return 'Nuevo punto';
  });

  readonly nodosSelectOptions = computed<NodoSelectOption[]>(() => {
    return this.nodosState().map((n) => ({
      value: n.idRedNodo,
      label: n.nodo,
    }));
  });

  readonly tiposCompatibles = computed(() => {
    const geomTipo = this.currentGeomTipo();
    const tipos = this.tiposState();

    if (!geomTipo) return tipos;

    return tipos.filter(
      (t) => t.geometriaPermitida === geomTipo || t.geometriaPermitida === 'mixed'
    );
  });

  readonly tiposAgrupados = computed<TipoAgrupadoVm[]>(() => {
    const orderedGroups: TipoAgrupadoVm[] = [];
    const byGroup = new Map<string, TipoAgrupadoVm>();

    for (const tipo of this.tiposCompatibles()) {
      const agrupacion = this.normalizeGrouping(tipo.agrupacion);

      let group = byGroup.get(agrupacion);
      if (!group) {
        group = { agrupacion, tipos: [] };
        byGroup.set(agrupacion, group);
        orderedGroups.push(group);
      }

      group.tipos.push(tipo);
    }

    return orderedGroups;
  });

  open(params: { wkt: string; geomTipo: MapaGeomTipo; nodoId?: number | null; title?: string | null; defaultNombre?: string | null; defaultDescripcion?: string | null }) {
    this.visible.set(true);
    this.saving.set(false);
    this.error.set(null);
    this.submittedAttempt.set(false);
    this.currentWkt.set(params.wkt);
    this.currentGeomTipo.set(params.geomTipo);
    this.customTitle.set(params.title ?? null);

    const incomingNodeId = params.nodoId ?? null;

    this.form.controls.idRedNodoFk.enable({ emitEvent: false });
    this.form.controls.idGeoTipoElementoFk.enable({ emitEvent: false });

    this.form.reset(
      {
        idRedNodoFk: incomingNodeId,
        idGeoTipoElementoFk: null,
        nombre: params.defaultNombre ?? '',
        descripcion: params.defaultDescripcion ?? '',
        etiqueta: '',
        estado: 'activo',
        visible: true,
        ordenDibujo: 0,
      },
      { emitEvent: false }
    );

    this.nodeLocked.set(incomingNodeId != null);

    if (incomingNodeId != null) {
      this.form.controls.idRedNodoFk.disable({ emitEvent: false });
    } else {
      this.form.controls.idRedNodoFk.enable({ emitEvent: false });
    }

    this.ensureTipoSelection();

    this.form.markAsPristine();
    this.form.markAsUntouched();
  }
  onVisibleChange(nextVisible: boolean) {
    if (nextVisible) {
      this.visible.set(true);
      return;
    }
    // Si se oculto para ajustar el trazo en el mapa, no preguntar por descartar.
    if (this.adjusting()) {
      this.visible.set(false);
      return;
    }

    this.requestClose();
  }

  /** Pide ajustar el trazo en el mapa: oculta el formulario (sin descartar) y avisa al contenedor. */
  pedirAjuste() {
    const wkt = this.currentWkt();
    const geomTipo = this.currentGeomTipo();
    if (!wkt || !geomTipo || this.saving()) return;
    this.adjusting.set(true);
    this.visible.set(false);
    this.requestAdjust.emit({ wkt, geomTipo });
  }

  /** Aplica el trazo ya ajustado y reabre el formulario con los mismos datos. */
  applyAdjustedWkt(wkt: string) {
    this.currentWkt.set(wkt);
    this.adjusting.set(false);
    this.visible.set(true);
  }

  /** Cancela el ajuste y reabre el formulario sin cambios en la geometria. */
  cancelAdjust() {
    this.adjusting.set(false);
    this.visible.set(true);
  }
  requestClose() {
    if (this.saving()) {
      return;
    }

    if (!this.hasPendingChanges()) {
      this.discardAndClose();
      return;
    }

    /*
     * PrimeNG emite visibleChange(false) cuando se pulsa la X o la mascara.
     * Sincronizamos visible=false y, si el usuario elige "Seguir editando",
     * forzamos false -> true para que el p-dialog vuelva a abrir.
     */
    this.visible.set(false);

    this.confirmDialog?.open(
      {
        title: 'Descartar nuevo elemento',
        message:
          'Hay un elemento nuevo sin guardar.\n\nSi continúas, la geometría y los datos capturados se perderán.',
        confirmLabel: 'Descartar cambios',
        cancelLabel: 'Seguir editando',
        severity: 'warning',
      },
      () => {
        this.discardAndClose();
      },
      () => {
        this.reopenCurrentDraft();
      }
    );
  }

  private reopenCurrentDraft() {
    if (!this.currentWkt() || this.saving()) {
      return;
    }

    this.visible.set(false);

    queueMicrotask(() => {
      if (this.currentWkt() && !this.saving()) {
        this.visible.set(true);
      }
    });
  }

guardar() {
    if (this.saving()) {
      return;
    }

    this.error.set(null);
    this.submittedAttempt.set(true);

    if (!this.currentWkt()) {
      this.error.set('No hay geometría.');
      return;
    }

    if (!this.currentGeomTipo()) {
      this.error.set('No se pudo leer la geometría.');
      return;
    }

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.error.set('Revisa los campos obligatorios.');
      return;
    }

    const payload = this.buildPayload();

    this.confirmDialog?.open(
      {
        title: 'Guardar nuevo elemento',
        message:
          'Se guardará el nuevo elemento con la geometría dibujada.\n\n¿Deseas continuar?',
        confirmLabel: 'Guardar',
        cancelLabel: 'Seguir editando',
        alternateLabel: 'Descartar',
        severity: 'info',
      },
      () => {
        this.saving.set(true);
        this.error.set(null);
        this.submitted.emit(payload);
      },
      undefined,
      () => {
        this.discardAndClose();
      }
    );
  }

  markSaving() {
    this.saving.set(true);
    this.error.set(null);
  }

  handleSaveSuccess() {
    this.saving.set(false);
    this.closeImmediately();
  }

  handleSaveError(message: string) {
    this.saving.set(false);
    this.error.set(message || 'No se pudo guardar el elemento.');
  }

  private discardAndClose() {
    this.closeImmediately();
    this.cancelled.emit();
  }

  selectedNodoDisplay(): string {
    const nodeId = this.form.getRawValue().idRedNodoFk;
    if (nodeId == null) return '';

    const found = this.nodosState().find((n) => n.idRedNodo === nodeId);
    if (found) return found.nodo;

    return `Nodo #${nodeId}`;
  }

  controlInvalid(name: keyof CreateElementoFormValue): boolean {
    const control = this.form.controls[name];
    return control.invalid && (control.touched || this.submittedAttempt());
  }

  controlError(name: keyof CreateElementoFormValue): string | null {
    const control = this.form.controls[name];

    if (!this.controlInvalid(name)) return null;

    if (control.errors?.['required']) {
      switch (name) {
        case 'idRedNodoFk':
          return 'Selecciona un nodo.';
        case 'idGeoTipoElementoFk':
          return 'Selecciona un tipo.';
        case 'nombre':
          return 'Ingresa el nombre.';
        default:
          return 'Campo obligatorio.';
      }
    }

    if (control.errors?.['maxlength']) {
      if (name === 'nombre') return 'Máximo 180 caracteres.';
      if (name === 'descripcion') return 'Máximo 500 caracteres.';
      if (name === 'etiqueta') return 'Máximo 120 caracteres.';
      return 'Valor demasiado largo.';
    }

    if (control.errors?.['min']) {
      return 'No puede ser negativo.';
    }

    return 'Valor inválido.';
  }

  isTipoSelected(tipo: MapaTipoElemento): boolean {
    return this.form.controls.idGeoTipoElementoFk.value === tipo.idGeoTipoElemento;
  }

  onTipoPicked(tipoId: number) {
    if (this.form.controls.idGeoTipoElementoFk.value === tipoId) {
      return;
    }

    this.form.controls.idGeoTipoElementoFk.setValue(tipoId);
    this.form.controls.idGeoTipoElementoFk.markAsDirty();
    this.error.set(null);
  }

  visual(tipo: MapaTipoElemento): MapaItemVisualPreview {
    return resolveMapaTipoVisual(tipo);
  }

  previewShapeClass(tipo: MapaTipoElemento): string {
    return previewShapeClassForVisual(this.visual(tipo));
  }

  previewStyle(tipo: MapaTipoElemento): Record<string, string> {
    return previewStyleForVisual(this.visual(tipo));
  }

  previewMaterialFamily(tipo: MapaTipoElemento): string {
    return previewMaterialFamilyForVisual(this.visual(tipo));
  }

  previewMaterialGlyph(tipo: MapaTipoElemento): string {
    return previewMaterialGlyphForVisual(this.visual(tipo));
  }

  previewClass(tipo: MapaTipoElemento): string {
    return previewClassForVisual(this.visual(tipo));
  }

  previewImageUrl(tipo: MapaTipoElemento): string {
    return previewImageUrlForVisual(this.visual(tipo));
  }

  showMaterialPreview(tipo: MapaTipoElemento): boolean {
    return showMaterialPreviewForVisual(this.visual(tipo));
  }

  showClassPreview(tipo: MapaTipoElemento): boolean {
    return showClassPreviewForVisual(this.visual(tipo));
  }

  showUrlPreview(tipo: MapaTipoElemento): boolean {
    return showUrlPreviewForVisual(this.visual(tipo));
  }

  trackByTipo = (_: number, item: MapaTipoElemento) => item.idGeoTipoElemento;
  trackByGrupo = (_: number, item: TipoAgrupadoVm) => item.agrupacion;

  private ensureTipoSelection() {
    const geomTipo = this.currentGeomTipo();
    if (!geomTipo) {
      return;
    }

    const compatibles = this.resolveTiposCompatibles(geomTipo);
    const currentId = this.form.controls.idGeoTipoElementoFk.value;

    if (!compatibles.length) {
      this.form.controls.idGeoTipoElementoFk.setValue(null, { emitEvent: false });
      return;
    }

    const exists = compatibles.some((t) => t.idGeoTipoElemento === currentId);
    if (!exists) {
      this.form.controls.idGeoTipoElementoFk.setValue(
        compatibles[0].idGeoTipoElemento,
        { emitEvent: false }
      );
    }
  }

  private buildPayload(): MapaElementoSaveRequest {
    const raw = this.form.getRawValue();

    return {
      idRedNodoFk: raw.idRedNodoFk as number,
      idGeoTipoElementoFk: raw.idGeoTipoElementoFk as number,
      nombre: raw.nombre.trim(),
      descripcion: this.emptyToNull(raw.descripcion) ?? '',
      etiqueta: this.emptyToNull(raw.etiqueta),
      estado: raw.estado,
      visible: raw.visible ?? true,
      origen: 'manual',
      wkt: this.currentWkt() as string,
      ordenDibujo: Number.isFinite(raw.ordenDibujo) ? raw.ordenDibujo : 0,
    };
  }

  private hasPendingChanges(): boolean {
    return !!this.currentWkt() || this.form.dirty;
  }

  private closeImmediately() {
    this.visible.set(false);
    this.saving.set(false);
    this.error.set(null);
    this.submittedAttempt.set(false);
    this.currentWkt.set(null);
    this.currentGeomTipo.set(null);
    this.customTitle.set(null);
    this.nodeLocked.set(false);

    this.form.controls.idRedNodoFk.enable({ emitEvent: false });
    this.form.controls.idGeoTipoElementoFk.enable({ emitEvent: false });

    this.form.reset(
      {
        idRedNodoFk: null,
        idGeoTipoElementoFk: null,
        nombre: '',
        descripcion: '',
        etiqueta: '',
        estado: 'activo',
        visible: true,
        ordenDibujo: 0,
      },
      { emitEvent: false }
    );

    this.form.markAsPristine();
    this.form.markAsUntouched();
  }

  private resolveTiposCompatibles(geomTipo: MapaGeomTipo): MapaTipoElemento[] {
    return this.tiposState().filter(
      (t) => t.geometriaPermitida === geomTipo || t.geometriaPermitida === 'mixed'
    );
  }

  private emptyToNull(value: string | null | undefined): string | null {
    const trimmed = (value ?? '').trim();
    return trimmed ? trimmed : null;
  }

  private normalizeGrouping(value: string | null | undefined): string {
    const normalized = String(value ?? '').trim();
    return normalized || 'Sin agrupación';
  }
}