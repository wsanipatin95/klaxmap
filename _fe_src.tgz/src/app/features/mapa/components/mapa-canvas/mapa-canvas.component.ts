import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import type * as Leaflet from 'leaflet';

import type {
  MapaElemento,
  MapaGeomTipo,
  MapaTipoElemento,
} from '../../data-access/mapa.models';
import type { MapaGeoSearchResult } from '../../models/mapa-geo-search.models';
import type { MapaToolMode } from '../../store/mapa-ui.store';
import type { BasemapKey } from '../../models/mapa-basemap.models';
import { MAPA_BASEMAP_OPTIONS } from '../../models/mapa-basemap.models';
import { parseWktGeometry } from '../../utils/mapa-geometry.utils';
import {
  normalizeMapaColor,
  normalizeMapaColorOrDefault,
} from '../../utils/mapa-color.utils';

declare const L: typeof import('leaflet');

export interface MapaEditSessionState {
  active: boolean;
  dirty: boolean;
  elementId: number | null;
  elementName: string | null;
  geomTipo: MapaGeomTipo | null;
}

interface ResolvedElementStyle {
  iconoFuente: string | null;
  icono: string | null;
  iconoClase: string | null;
  colorFill: string;
  colorStroke: string;
  colorTexto: string | null;
  strokeWidth: number;
  zIndex: number;
  tamanoIcono: number;
}

interface CachedElementBounds {
  signature: string;
  bounds: L.LatLngBounds | null;
}

interface MeasureState {
  points: L.LatLng[];
  previewPoint: L.LatLng | null;
  finished: boolean;
}

interface LabelCollisionBox {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

interface LabelCandidate {
  elemento: MapaElemento;
  layer: L.Layer;
  anchor: L.LatLng;
  name: string;
  priority: number;
  selected: boolean;
}

@Component({
  selector: 'app-mapa-canvas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './mapa-canvas.component.html',
  styleUrl: './mapa-canvas.component.scss',
  encapsulation: ViewEncapsulation.None,
})
export class MapaCanvasComponent implements AfterViewInit, OnChanges, OnDestroy {
  @ViewChild('mapContainer', { static: true }) mapContainer!: ElementRef<HTMLDivElement>;

  @Input() elementos: MapaElemento[] = [];
  @Input() tipos: MapaTipoElemento[] = [];
  @Input() selectedElementoId: number | null = null;
  @Input() toolMode: MapaToolMode = 'select';
  @Input() hiddenTipoIds: number[] = [];
  @Input() basemap: BasemapKey = 'osm';
  @Input() labelsVisible = true;
  @Input() mapCenter: L.LatLngTuple = [-0.22985, -78.52495];
  @Input() mapZoom = 13;

  @Output() elementoSelected = new EventEmitter<MapaElemento | null>();
  @Output() elementoContext = new EventEmitter<{ elemento: MapaElemento; x: number; y: number }>();
  @Output() geometryCreated = new EventEmitter<{ wkt: string; geomTipo: MapaGeomTipo }>();
  @Output() editSessionStateChanged = new EventEmitter<MapaEditSessionState>();

  measureActive = false;
  measureStarted = false;
  measureDistanceText = '0 m';

  private readonly DEFAULT_STROKE = '#7b0061';
  private readonly DEFAULT_FILL = '#f3aad6';
  private readonly EDIT_STROKE = '#2563eb';
  private readonly EDIT_FILL = '#60a5fa';
  private readonly LABELS_MIN_ZOOM = 12;
  private readonly LABELS_MAX_VISIBLE = 110;
  private readonly LABELS_PERFORMANCE_MAX_VISIBLE = 56;
  private readonly MEASURE_STROKE = '#f59e0b';
  private readonly MEASURE_FILL = '#fde68a';

  private readonly PERFORMANCE_THRESHOLD = 5000;
  private readonly SIMPLIFY_POINTS_BELOW_ZOOM = 14;
  private readonly VIEWPORT_PAD_FACTOR = 0.85;
  private readonly PERFORMANCE_POINT_RADIUS = 5;

  private map!: L.Map;
  private baseLayer!: L.TileLayer;
  private activeBasemapKey: BasemapKey = 'osm';
  private readonly drawnItems = new L.FeatureGroup();
  private readonly measureLayer = new L.FeatureGroup();
  private readonly searchLayer = new L.FeatureGroup();
  private readonly labelsLayer = new L.LayerGroup();
  private readonly renderedLayers = new Map<number, L.Layer>();
  private readonly elementBoundsCache = new Map<number, CachedElementBounds>();
  // Renderer SVG (no canvas): permite rotacion (leaflet-rotate) manteniendo el clic en lineas/puntos.
  private readonly vectorRenderer = L.svg({ padding: 0.8 });

  private activeDrawHandler: any = null;
  private draftEditLayer: L.Layer | null = null;
  private draftEditGeomTipo: MapaGeomTipo | null = null;
  private drawingKeyType: 'point' | 'line' | 'polygon' | null = null;
  // Borrar el ultimo nodo (Backspace/Supr) o cancelar el trazo (Esc) mientras se dibuja una linea/poligono.
  private onDrawKeydown = (e: KeyboardEvent) => {
    if (!this.activeDrawHandler) return;
    if (e.key === 'Escape') {
      e.preventDefault();
      this.stopActiveDraw();
      return;
    }
    if ((e.key === 'Backspace' || e.key === 'Delete') && this.drawingKeyType !== 'point') {
      const target = e.target as HTMLElement | null;
      const tag = target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || target?.isContentEditable) return;
      e.preventDefault();
      this.activeDrawHandler?.deleteLastVertex?.();
    }
  };
  private renderFrameId: number | null = null;
  private resizeRefreshFrameId: number | null = null;
  private lastRefreshSize: L.Point | null = null;
  private currentViewBounds: L.LatLngBounds | null = null;
  private hasInitialAutoFit = false;
  private drawPluginAvailable = false;
  private resizeObserver: ResizeObserver | null = null;
  private lastTooltipOpenedElementoId: number | null = null;

  private editSession: {
    active: boolean;
    dirty: boolean;
    elementId: number | null;
    elementName: string | null;
    geomTipo: MapaGeomTipo | null;
    originalWkt: string | null;
    currentWkt: string | null;
    layer: L.Layer | null;
    originalSnapshot: L.Layer | null;
  } = {
      active: false,
      dirty: false,
      elementId: null,
      elementName: null,
      geomTipo: null,
      originalWkt: null,
      currentWkt: null,
      layer: null,
      originalSnapshot: null,
    };

  private measureState: MeasureState = {
    points: [],
    previewPoint: null,
    finished: false,
  };

  private get performanceModeEnabled(): boolean {
    return this.elementos.length >= this.PERFORMANCE_THRESHOLD;
  }

  private get currentZoom(): number {
    return this.map ? this.map.getZoom() : this.mapZoom;
  }

  ngAfterViewInit(): void {
    this.initMap();
    this.updateViewBounds();
    this.fitInitialBoundsIfNeeded();
    this.scheduleRender();
    this.syncToolMode();
    this.setupResizeObserver();
    this.scheduleMapResizeRefresh();
    this.scheduleRobustMapLayoutRefresh();
  }

  ngOnDestroy(): void {
    if (this.renderFrameId != null) {
      window.cancelAnimationFrame(this.renderFrameId);
    }

    if (this.resizeRefreshFrameId != null) {
      window.cancelAnimationFrame(this.resizeRefreshFrameId);
    }

    this.resizeObserver?.disconnect();
    window.removeEventListener('keydown', this.onDrawKeydown);
    this.cancelDraftGeometryEdit();

    if (this.map) {
      this.map.remove();
    }
  }

  @HostListener('window:resize')
  onWindowResize() {
    this.scheduleMapResizeRefresh();
  }

  @HostListener('window:orientationchange')
  onWindowOrientationChange() {
    this.scheduleMapResizeRefresh();
    window.setTimeout(() => this.scheduleMapResizeRefresh(), 180);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.map) return;

    const dataChanged =
      changes['elementos'] ||
      changes['selectedElementoId'] ||
      changes['tipos'] ||
      changes['hiddenTipoIds'];

    if (changes['elementos'] && !this.hasInitialAutoFit) {
      this.fitInitialBoundsIfNeeded();
    }

    if (dataChanged) {
      if (!this.editSession.active) {
        this.scheduleRender();
      } else {
        this.scheduleRenderKeepingDraft();
      }
    }

    if (changes['toolMode'] || changes['selectedElementoId']) {
      this.syncToolMode();
    }

    if (changes['labelsVisible']) {
      this.scheduleRender();
    }

    if (changes['basemap']) {
      this.applyBasemap(this.basemap);
    }

    if ((changes['mapCenter'] || changes['mapZoom']) && this.map) {
      this.map.setView(this.mapCenter, this.mapZoom);
      this.updateViewBounds();
      this.scheduleRender();
    }
  }

  refreshMapLayout(preserveView = true) {
    this.scheduleMapResizeRefresh(preserveView);
    this.scheduleRobustMapLayoutRefresh(preserveView);
    this.forceBaseTilesRedraw();
  }

  /**
   * Fuerza la recarga de los tiles de la capa base tras un cambio de layout
   * explicito (abrir/cerrar el panel lateral, entrar a modo responsive/movil).
   * En esos casos Leaflet puede dejar el mapa en gris aunque el tamano no cambie;
   * un redraw garantiza que los tiles se vuelvan a pedir y el mapa nunca quede gris.
   */
  private forceBaseTilesRedraw() {
    if (typeof window === 'undefined') {
      return;
    }
    window.requestAnimationFrame(() => {
      if (!this.map || !this.baseLayer) {
        return;
      }
      this.lastRefreshSize = this.map.getSize();
      this.baseLayer.redraw?.();
    });
  }

  clearMeasurement() {
    this.measureState = {
      points: [],
      previewPoint: null,
      finished: false,
    };
    this.measureStarted = false;
    this.measureDistanceText = '0 m';
    this.measureLayer.clearLayers();
  }

  clearTemporarySearchMarker() {
    this.searchLayer.clearLayers();
  }

  centerOnCoordinate(lat: number, lng: number, zoom = 17) {
    if (!this.map) {
      return;
    }

    this.map.setView([lat, lng], Math.max(this.currentZoom, zoom));
    this.updateViewBounds();
    this.scheduleRender();
  }

  focusOnSearchResult(result: MapaGeoSearchResult) {
    if (!this.map) {
      return;
    }

    this.renderSearchResult(result);

    const bounds = result.bounds
      ? L.latLngBounds(
        [result.bounds.south, result.bounds.west],
        [result.bounds.north, result.bounds.east]
      )
      : null;

    if (bounds?.isValid?.()) {
      this.map.fitBounds(bounds.pad(0.25), { maxZoom: 17 });
    } else {
      this.centerOnCoordinate(result.lat, result.lng, 17);
    }

    this.updateViewBounds();
    this.scheduleRender();
  }

  focusOnCurrentLocation(lat: number, lng: number, accuracyMeters?: number | null) {
    this.focusOnSearchResult({
      id: 'current-location',
      label:
        accuracyMeters && Number.isFinite(accuracyMeters)
          ? `Mi ubicación · precisión aprox. ${this.formatDistance(accuracyMeters)}`
          : 'Mi ubicación actual',
      subtitle: 'Ubicación obtenida desde el navegador',
      lat,
      lng,
      bounds: null,
      source: 'coordinates',
    });
  }

  centerOnElemento(id: number | null) {
    if (id == null || !this.map) return;

    const selected = this.renderedLayers.get(id);
    if (!selected) {
      this.scheduleRender();
      return;
    }

    const anchor = this.tryGetLayerLatLng(selected);
    if (!anchor) {
      this.scheduleRender();
      return;
    }

    let targetZoom = Math.max(this.currentZoom, 16);

    if ('getBounds' in selected && typeof (selected as any).getBounds === 'function') {
      const bounds = (selected as any).getBounds();
      if (bounds?.isValid?.()) {
        targetZoom = Math.max(this.resolveFocusedElementZoom(bounds), this.currentZoom);
      }
    } else if ('getLatLng' in selected && typeof (selected as any).getLatLng === 'function') {
      targetZoom = Math.max(this.currentZoom, 18);
    }

    this.map.setView(anchor, targetZoom, { animate: true });
    this.updateViewBounds();
    this.openTooltipForLayer(selected);
    this.lastTooltipOpenedElementoId = id;
    this.scheduleRender();
  }

  panToElementoPreservingZoom(id: number | null) {
    if (id == null || !this.map) return;

    const layer = this.renderedLayers.get(id) ?? null;
    const anchor = layer
      ? this.tryGetLayerLatLng(layer)
      : this.getElementAnchorById(id);

    if (!anchor) {
      this.scheduleRender();
      return;
    }

    this.map.panTo(anchor, { animate: true });
    this.updateViewBounds();
    this.scheduleRender();

    const rendered = this.renderedLayers.get(id) ?? layer;
    this.openTooltipForLayer(rendered);
    this.lastTooltipOpenedElementoId = id;
  }

  private getElementAnchorById(id: number): L.LatLng | null {
    const item = this.elementos.find((el) => el.idGeoElemento === id) ?? null;
    if (!item) return null;

    const bounds = this.getElementBounds(item);
    return bounds?.isValid?.() ? bounds.getCenter() : null;
  }

  private resolveFocusedElementZoom(bounds: L.LatLngBounds): number {
    const diagonalMeters = this.map.distance(bounds.getSouthWest(), bounds.getNorthEast());

    if (!Number.isFinite(diagonalMeters) || diagonalMeters <= 0) {
      return 16;
    }

    if (diagonalMeters <= 20) return 19;
    if (diagonalMeters <= 80) return 18;
    if (diagonalMeters <= 250) return 17;
    if (diagonalMeters <= 800) return 16;
    if (diagonalMeters <= 2500) return 15;
    if (diagonalMeters <= 8000) return 14;
    if (diagonalMeters <= 25000) return 13;
    if (diagonalMeters <= 70000) return 12;
    if (diagonalMeters <= 150000) return 11;

    return 10;
  }

  centerOnElementos(elementos: MapaElemento[]) {
    if (!this.map || !Array.isArray(elementos) || elementos.length === 0) {
      return;
    }

    const bounds = L.latLngBounds([]);

    for (const item of elementos) {
      const layer = this.renderedLayers.get(item.idGeoElemento);

      if (layer) {
        if ('getBounds' in layer && typeof (layer as any).getBounds === 'function') {
          const layerBounds = (layer as any).getBounds();
          if (layerBounds?.isValid?.()) {
            bounds.extend(layerBounds);
            continue;
          }
        }

        if ('getLatLng' in layer && typeof (layer as any).getLatLng === 'function') {
          bounds.extend((layer as any).getLatLng());
          continue;
        }
      }

      const cachedBounds = this.getElementBounds(item);
      if (cachedBounds?.isValid?.()) {
        bounds.extend(cachedBounds);
      }
    }

    if (bounds.isValid()) {
      this.map.fitBounds(bounds.pad(0.2));
      this.updateViewBounds();
      this.scheduleRender();
    }
  }

  hasPendingEditChanges(): boolean {
    return this.editSession.active && this.editSession.dirty;
  }

  isEditingElement(elementId: number | null): boolean {
    return this.editSession.active && this.editSession.elementId === elementId;
  }

  saveEditSession(): { idGeoElemento: number; geomTipo: MapaGeomTipo; wkt: string } | null {
    if (!this.editSession.active) {
      return null;
    }

    this.syncEditSessionFromLayer();

    if (
      !this.editSession.dirty ||
      this.editSession.elementId == null ||
      !this.editSession.geomTipo ||
      !this.editSession.currentWkt
    ) {
      return null;
    }

    const payload = {
      idGeoElemento: this.editSession.elementId,
      geomTipo: this.editSession.geomTipo,
      wkt: this.editSession.currentWkt,
    };

    this.disableLayerEditing(this.editSession.layer);
    this.clearEditSession();
    this.emitEditSessionState();
    this.scheduleRender();

    return payload;
  }

  cancelEditSession() {
    if (!this.editSession.active) return;

    if (this.editSession.layer && this.editSession.originalSnapshot) {
      this.replaceLayerGeometry(this.editSession.layer, this.editSession.originalSnapshot);
    }

    this.disableLayerEditing(this.editSession.layer);
    this.clearEditSession();
    this.emitEditSessionState();
    this.scheduleRender();
  }

  // ---- Ajuste del trazo de un elemento NUEVO (aun no guardado), desde el formulario.
  /** Construye una capa simple editable (sin estilos compuestos) desde un WKT, para ajustar vertices. */
  private buildSimpleEditableLayer(wkt: string, geomTipo: MapaGeomTipo): L.Layer | null {
    const parsed = parseWktGeometry(wkt);
    if (!parsed) return null;
    if (geomTipo === 'point' && parsed.point) {
      return L.marker(L.latLng(parsed.point[0], parsed.point[1]), { draggable: true });
    }
    if (geomTipo === 'linestring' && parsed.line) {
      return L.polyline(parsed.line as L.LatLngExpression[], { color: this.EDIT_STROKE, weight: 4 });
    }
    if (geomTipo === 'polygon' && parsed.polygon) {
      return L.polygon(parsed.polygon as L.LatLngExpression[][], {
        color: this.EDIT_STROKE, weight: 3, fillColor: this.EDIT_FILL, fillOpacity: 0.2,
      });
    }
    return null;
  }

  /** Inicia el ajuste del trazo nuevo: muestra la geometria editable (arrastrar vertices, puntos medios para agregar). */
  startDraftGeometryEdit(wkt: string, geomTipo: MapaGeomTipo): boolean {
    if (!this.map) return false;
    this.cancelDraftGeometryEdit();
    const layer = this.buildSimpleEditableLayer(wkt, geomTipo);
    if (!layer) return false;
    layer.addTo(this.map);
    const anyLayer = layer as any;
    if (typeof anyLayer.editing?.enable === 'function') anyLayer.editing.enable();
    if (geomTipo === 'point' && typeof anyLayer.dragging?.enable === 'function') anyLayer.dragging.enable();
    this.draftEditLayer = layer;
    this.draftEditGeomTipo = geomTipo;
    try {
      if (typeof anyLayer.getBounds === 'function') {
        this.map.fitBounds(anyLayer.getBounds(), { padding: [40, 40], maxZoom: 18 });
      } else if (typeof anyLayer.getLatLng === 'function') {
        this.map.setView(anyLayer.getLatLng(), Math.max(this.map.getZoom(), 17));
      }
    } catch { /* geometria invalida */ }
    return true;
  }

  /** Termina el ajuste y devuelve el WKT actualizado del trazo. */
  finishDraftGeometryEdit(): { wkt: string; geomTipo: MapaGeomTipo } | null {
    if (!this.draftEditLayer || !this.draftEditGeomTipo) return null;
    const anyLayer = this.draftEditLayer as any;
    anyLayer.editing?.disable?.();
    anyLayer.dragging?.disable?.();
    const geomTipo = this.draftEditGeomTipo;
    const wkt = this.layerToWkt(this.draftEditLayer, geomTipo);
    this.map?.removeLayer(this.draftEditLayer);
    this.draftEditLayer = null;
    this.draftEditGeomTipo = null;
    return wkt ? { wkt, geomTipo } : null;
  }

  /** Cancela el ajuste sin cambios (descarta el ajuste, no el trazo: el formulario conserva el WKT anterior). */
  cancelDraftGeometryEdit(): void {
    if (!this.draftEditLayer) return;
    const anyLayer = this.draftEditLayer as any;
    anyLayer.editing?.disable?.();
    anyLayer.dragging?.disable?.();
    this.map?.removeLayer(this.draftEditLayer);
    this.draftEditLayer = null;
    this.draftEditGeomTipo = null;
  }

  private getDrawRef(): any | null {
    const drawRef = (L as any)?.Draw ?? null;
    return drawRef;
  }

  private detectDrawPlugin(): boolean {
    const drawRef = this.getDrawRef();
    return !!(
      drawRef &&
      drawRef.Event &&
      typeof drawRef.Marker === 'function' &&
      typeof drawRef.Polyline === 'function' &&
      typeof drawRef.Polygon === 'function'
    );
  }

  private initMap() {
    // Rotacion habilitada (leaflet-rotate, cargado por angular.json scripts).
    // Con renderer SVG el clic en lineas/puntos sigue funcionando aunque se rote.
    this.map = L.map(this.mapContainer.nativeElement, {
      center: this.mapCenter,
      zoom: this.mapZoom,
      zoomControl: true,
      preferCanvas: false,
      maxZoom: 20,
      rotate: true,
      bearing: 0,
      rotateControl: { closeOnZeroBearing: false, position: 'topleft' },
      touchRotate: true,
      shiftKeyRotate: true,
    } as any);

    this.applyBasemap(this.basemap);

    this.drawnItems.addTo(this.map);
    this.measureLayer.addTo(this.map);
    this.searchLayer.addTo(this.map);
    this.labelsLayer.addTo(this.map);

    this.map.on('click', (event: L.LeafletMouseEvent) => {
      if (this.toolMode === 'measure') {
        this.handleMeasureClick(event.latlng);
      }
    });

    this.map.on('mousemove', (event: L.LeafletMouseEvent) => {
      if (this.toolMode === 'measure') {
        this.handleMeasureMouseMove(event.latlng);
      }
    });

    this.map.on('dblclick', (event: L.LeafletMouseEvent) => {
      if (this.toolMode === 'measure') {
        L.DomEvent.stop(event.originalEvent);
        this.finishMeasurement();
      }
    });

    this.map.on('moveend zoomend resize', () => {
      this.updateViewBounds();

      if (!this.editSession.active) {
        this.scheduleRender();
      } else {
        this.scheduleRenderKeepingDraft();
      }
    });

    this.drawPluginAvailable = this.detectDrawPlugin();

    const drawRef = this.getDrawRef();

    if (drawRef?.Event?.CREATED) {
      this.map.on(drawRef.Event.CREATED, (e: any) => {
        const layer = e.layer as L.Layer;
        const geomTipo = this.geomTipoFromLayerType(e.layerType);
        const wkt = this.layerToWkt(layer, geomTipo);

        const stoppedHandler = this.stopActiveDraw();

        if (!wkt) {
          this.schedulePostDrawCleanup(stoppedHandler);
          return;
        }

        this.geometryCreated.emit({ wkt, geomTipo });

        this.schedulePostDrawCleanup(stoppedHandler);
      });
    }
  }

  private applyBasemap(key: BasemapKey) {
    if (!this.map) {
      this.activeBasemapKey = key;
      return;
    }

    if (this.baseLayer && this.activeBasemapKey === key) {
      return;
    }

    const config = MAPA_BASEMAP_OPTIONS.find((item) => item.key === key) ?? MAPA_BASEMAP_OPTIONS[0];

    if (this.baseLayer) {
      this.map.removeLayer(this.baseLayer);
    }

    this.baseLayer = L.tileLayer(config.url, config.options);
    this.baseLayer.addTo(this.map);
    this.activeBasemapKey = config.key;
  }

  private setupResizeObserver() {
    if (typeof ResizeObserver === 'undefined' || !this.mapContainer?.nativeElement) {
      return;
    }

    const container = this.mapContainer.nativeElement;
    this.resizeObserver = new ResizeObserver(() => {
      this.scheduleMapResizeRefresh();
    });

    this.resizeObserver.observe(container);

    if (container.parentElement) {
      this.resizeObserver.observe(container.parentElement);
    }
  }


  private scheduleRobustMapLayoutRefresh(preserveView = true) {
    if (typeof window === 'undefined') {
      return;
    }

    const delays = [60, 180, 360, 720];

    for (const delay of delays) {
      window.setTimeout(() => {
        this.scheduleMapResizeRefresh(preserveView);
      }, delay);
    }
  }

  private scheduleMapResizeRefresh(preserveView = true) {
    if (!this.map) {
      return;
    }

    if (this.resizeRefreshFrameId != null) {
      window.cancelAnimationFrame(this.resizeRefreshFrameId);
    }

    this.resizeRefreshFrameId = window.requestAnimationFrame(() => {
      this.resizeRefreshFrameId = null;

      const center = preserveView ? this.map.getCenter() : null;
      const zoom = preserveView ? this.map.getZoom() : null;

      this.map.invalidateSize({ pan: false });

      if (center && zoom != null) {
        this.map.setView(center, zoom, { animate: false });
      }

      // Tras un cambio de tamano del contenedor (entrar a modo movil/responsive,
      // abrir o cerrar el panel lateral a ancho angosto, cambio de orientacion o
      // de devicePixelRatio) Leaflet recalcula la geometria pero la capa de tiles
      // no siempre vuelve a pedir los tiles del area nueva: el mapa queda gris.
      // Cuando el tamano del mapa realmente cambia forzamos un redraw de la capa
      // base para que los tiles se vuelvan a cargar y nunca quede en gris.
      const size = this.map.getSize();
      const sizeChanged =
        !this.lastRefreshSize ||
        this.lastRefreshSize.x !== size.x ||
        this.lastRefreshSize.y !== size.y;

      if (sizeChanged) {
        this.lastRefreshSize = size;
        this.baseLayer?.redraw?.();
      }

      this.updateViewBounds();
      this.scheduleRender();
    });
  }

  private updateViewBounds() {
    if (!this.map) {
      this.currentViewBounds = null;
      return;
    }

    this.currentViewBounds = this.map.getBounds();
  }

  private fitInitialBoundsIfNeeded() {
    if (!this.map || this.hasInitialAutoFit || !this.elementos.length || this.selectedElementoId != null) {
      return;
    }

    const hiddenSet = new Set(this.hiddenTipoIds);
    const bounds = L.latLngBounds([]);

    for (const item of this.elementos) {
      if (hiddenSet.has(item.idGeoTipoElementoFk)) {
        continue;
      }

      const itemBounds = this.getElementBounds(item);
      if (itemBounds?.isValid?.()) {
        bounds.extend(itemBounds);
      }
    }

    if (bounds.isValid()) {
      this.map.fitBounds(bounds.pad(0.2));
      this.updateViewBounds();
      this.hasInitialAutoFit = true;
    }
  }

  private scheduleRender() {
    if (!this.map) return;
    if (this.renderFrameId != null) return;

    this.renderFrameId = window.requestAnimationFrame(() => {
      this.renderFrameId = null;
      this.renderElementos();
    });
  }

  private scheduleRenderKeepingDraft() {
    if (!this.map) return;
    if (this.renderFrameId != null) return;

    this.renderFrameId = window.requestAnimationFrame(() => {
      this.renderFrameId = null;
      this.renderElementosKeepingDraft();
    });
  }

  private syncToolMode() {
    if (!this.map) return;

    const container = this.map.getContainer();
    this.map.dragging.enable();
    container.style.cursor = '';

    if (this.toolMode !== 'edit-geometry' && this.editSession.active) {
      this.disableLayerEditing(this.editSession.layer);
      this.clearEditSession();
      this.emitEditSessionState();
      this.scheduleRender();
    }

    if (this.toolMode !== 'measure' && this.measureActive) {
      this.disableMeasureMode(true);
    }

    if (!this.editSession.active && this.toolMode !== 'measure') {
      this.stopActiveDraw();
    }

    if (this.toolMode === 'select' || this.toolMode === 'move') {
      container.style.cursor = this.toolMode === 'move' ? 'grab' : '';
      return;
    }

    if (this.toolMode === 'draw-point') {
      this.map.dragging.disable();
      container.style.cursor = 'crosshair';
      this.startDrawHandler('point');
      return;
    }

    if (this.toolMode === 'draw-line') {
      this.map.dragging.disable();
      container.style.cursor = 'crosshair';
      this.startDrawHandler('line');
      return;
    }

    if (this.toolMode === 'draw-polygon') {
      this.map.dragging.disable();
      container.style.cursor = 'crosshair';
      this.startDrawHandler('polygon');
      return;
    }

    if (this.toolMode === 'edit-geometry') {
      this.stopActiveDraw();
      container.style.cursor = 'crosshair';
      this.ensureEditSessionForSelection();
      return;
    }

    if (this.toolMode === 'measure') {
      this.stopActiveDraw();
      this.map.dragging.disable();
      container.style.cursor = 'crosshair';
      this.enableMeasureMode();
    }
  }

  private ensureEditSessionForSelection() {
    if (this.selectedElementoId == null) {
      this.disableLayerEditing(this.editSession.layer);
      this.clearEditSession();
      this.emitEditSessionState();
      return;
    }

    if (this.editSession.active && this.editSession.elementId === this.selectedElementoId) {
      if (this.editSession.layer) {
        this.enableLayerEditing(this.editSession.layer);
      }
      this.emitEditSessionState();
      return;
    }

    const selectedElement =
      this.elementos.find((e) => e.idGeoElemento === this.selectedElementoId) ?? null;
    const layer = this.renderedLayers.get(this.selectedElementoId) ?? null;

    if (!selectedElement || !layer) {
      this.disableLayerEditing(this.editSession.layer);
      this.clearEditSession();
      this.emitEditSessionState();
      return;
    }

    this.disableLayerEditing(this.editSession.layer);

    const geomTipo =
      (selectedElement.geomTipo as MapaGeomTipo) || this.inferGeomTipoFromLayer(layer);
    const originalWkt = this.layerToWkt(layer, geomTipo);

    this.editSession = {
      active: true,
      dirty: false,
      elementId: selectedElement.idGeoElemento,
      elementName: selectedElement.nombre ?? null,
      geomTipo,
      originalWkt,
      currentWkt: originalWkt,
      layer,
      originalSnapshot: this.cloneLayer(layer),
    };

    this.enableLayerEditing(layer);
    this.emitEditSessionState();
  }

  private startDrawHandler(type: 'point' | 'line' | 'polygon') {
    if (!this.map) return;

    const DrawRef: any = this.getDrawRef();

    if (!DrawRef) {
      console.error('No se puede iniciar dibujo porque L.Draw no está disponible.');
      return;
    }

    this.stopActiveDraw();

    if (type === 'point') {
      this.activeDrawHandler = new DrawRef.Marker(this.map, {
        repeatMode: false,
      });
    }

    if (type === 'line') {
      this.activeDrawHandler = new DrawRef.Polyline(this.map, {
        repeatMode: false,
        shapeOptions: {
          color: this.EDIT_STROKE,
          weight: 4,
        },
      });
    }

    if (type === 'polygon') {
      this.activeDrawHandler = new DrawRef.Polygon(this.map, {
        repeatMode: false,
        shapeOptions: {
          color: this.EDIT_STROKE,
          weight: 3,
          fillColor: this.EDIT_FILL,
          fillOpacity: 0.2,
        },
      });
    }

    this.drawingKeyType = type;
    this.activeDrawHandler?.enable?.();
    window.addEventListener('keydown', this.onDrawKeydown);
  }
  private stopActiveDraw(): any | null {
    window.removeEventListener('keydown', this.onDrawKeydown);
    this.drawingKeyType = null;
    const handler = this.activeDrawHandler;
    this.activeDrawHandler = null;

    this.hardStopDrawHandler(handler);
    this.cleanupLeafletDrawArtifacts(handler);
    this.restoreMapInteractionAfterDraw();

    return handler;
  }

  private hardStopDrawHandler(handler: any | null) {
    if (!handler) {
      return;
    }

    try {
      // disable() YA invoca removeHooks() internamente y esta protegido por _enabled.
      // No llamamos removeHooks() de nuevo: hacerlo provoca un doble teardown (tooltip ya null)
      // que lanza error y deja los hooks de dibujo a medio quitar, bloqueando los clics del mapa.
      const enabled = typeof handler.enabled === 'function' ? handler.enabled() : handler._enabled;
      if (enabled) {
        handler.disable?.();
      }
    } catch (err) {
      console.warn('[MAPA][DRAW] No se pudo desactivar el handler de dibujo:', err);
    }

    // Por si quedo alguna guia de dibujo residual en el DOM (defensa adicional).
    this.removeLeftoverDrawGuides();
  }

  private removeLeftoverDrawGuides() {
    const container = this.map?.getContainer();
    if (!container) return;
    container
      .querySelectorAll('.leaflet-draw-guides, .leaflet-draw-guide-dash, .leaflet-draw-tooltip')
      .forEach((el) => el.remove());
  }

  private restoreMapInteractionAfterDraw() {
    if (!this.map) {
      return;
    }

    this.map.dragging.enable();

    if (this.toolMode !== 'measure') {
      this.map.doubleClickZoom.enable();
    }

    if (!this.editSession.active) {
      this.map.getContainer().style.cursor = '';
    }
  }

  private cleanupLeafletDrawArtifacts(handler: any | null) {
    if (!this.map) {
      return;
    }

    const safeRemoveLayer = (layer: any) => {
      if (!layer) {
        return;
      }

      try {
        if (typeof this.map.hasLayer === 'function' && this.map.hasLayer(layer)) {
          this.map.removeLayer(layer);
        }
      } catch {
        // no-op: algunos objetos internos de Leaflet Draw no siempre son Layer.
      }
    };

    try {
      handler?._markerGroup?.clearLayers?.();
    } catch {
      // no-op
    }

    safeRemoveLayer(handler?._markerGroup);
    safeRemoveLayer(handler?._poly);
    safeRemoveLayer(handler?._mouseMarker);

    const markers = Array.isArray(handler?._markers) ? handler._markers : [];
    for (const marker of markers) {
      safeRemoveLayer(marker);
    }

    try {
      handler?._tooltip?.dispose?.();
    } catch {
      // no-op
    }

    const selector =
      '.leaflet-draw-tooltip, .leaflet-draw-guide-dash, .leaflet-draw-draw-tooltip';

    const container = this.map.getContainer();
    container.querySelectorAll(selector).forEach((el) => el.remove());

    if (typeof document !== 'undefined') {
      document.querySelectorAll(selector).forEach((el) => el.remove());
    }
  }

  private schedulePostDrawCleanup(handler: any | null) {
    const cleanup = () => {
      this.hardStopDrawHandler(handler);
      this.cleanupLeafletDrawArtifacts(handler);
      this.restoreMapInteractionAfterDraw();

      if (
        this.toolMode !== 'draw-point' &&
        this.toolMode !== 'draw-line' &&
        this.toolMode !== 'draw-polygon'
      ) {
        this.cleanupLeafletDrawArtifacts(this.activeDrawHandler);
        this.activeDrawHandler = null;
      }

      this.scheduleRender();
    };

    cleanup();

    window.setTimeout(cleanup, 0);
    window.setTimeout(cleanup, 80);
    window.setTimeout(cleanup, 220);
  }

  private enableLayerEditing(layer: L.Layer | null) {
    if (!layer || !this.map) return;

    const anyLayer = layer as any;

    layer.off('drag', this.onLayerEdited);
    layer.off('dragend', this.onLayerEdited);
    layer.off('edit', this.onLayerEdited);

    this.map.off('mouseup', this.onMapInteractionFinished);
    this.map.off('touchend', this.onMapInteractionFinished);

    if (typeof anyLayer.dragging?.enable === 'function') {
      anyLayer.dragging.enable();
      layer.on('drag', this.onLayerEdited);
      layer.on('dragend', this.onLayerEdited);
    }

    if (typeof anyLayer.editing?.enable === 'function') {
      anyLayer.editing.enable();
      layer.on('edit', this.onLayerEdited);
    }

    this.map.on('mouseup', this.onMapInteractionFinished);
    this.map.on('touchend', this.onMapInteractionFinished);

    this.syncEditSessionFromLayer(true);
  }

  private disableLayerEditing(layer: L.Layer | null) {
    if (!layer) return;

    const anyLayer = layer as any;

    layer.off('drag', this.onLayerEdited);
    layer.off('dragend', this.onLayerEdited);
    layer.off('edit', this.onLayerEdited);

    if (this.map) {
      this.map.off('mouseup', this.onMapInteractionFinished);
      this.map.off('touchend', this.onMapInteractionFinished);
    }

    if (typeof anyLayer.dragging?.disable === 'function') {
      anyLayer.dragging.disable();
    }

    if (typeof anyLayer.editing?.disable === 'function') {
      anyLayer.editing.disable();
    }
  }

  private onLayerEdited = () => {
    queueMicrotask(() => {
      this.syncEditSessionFromLayer();
    });
  };

  private onMapInteractionFinished = () => {
    queueMicrotask(() => {
      this.syncEditSessionFromLayer();
    });
  };

  private syncEditSessionFromLayer(forceEmit = false) {
    if (!this.editSession.active || !this.editSession.layer || !this.editSession.geomTipo) {
      return;
    }

    const wkt = this.layerToWkt(this.editSession.layer, this.editSession.geomTipo);
    if (!wkt) {
      return;
    }

    const nextDirty = wkt !== this.editSession.originalWkt;
    const changed =
      this.editSession.currentWkt !== wkt ||
      this.editSession.dirty !== nextDirty;

    this.editSession.currentWkt = wkt;
    this.editSession.dirty = nextDirty;

    if (changed || forceEmit) {
      this.emitEditSessionState();
    }
  }

  private emitEditSessionState() {
    this.editSessionStateChanged.emit({
      active: this.editSession.active,
      dirty: this.editSession.dirty,
      elementId: this.editSession.elementId,
      elementName: this.editSession.elementName,
      geomTipo: this.editSession.geomTipo,
    });
  }

  private clearEditSession() {
    this.editSession = {
      active: false,
      dirty: false,
      elementId: null,
      elementName: null,
      geomTipo: null,
      originalWkt: null,
      currentWkt: null,
      layer: null,
      originalSnapshot: null,
    };
  }

  private enableMeasureMode() {
    if (this.measureActive) {
      return;
    }

    this.measureActive = true;
    this.measureStarted = this.measureState.points.length > 0;
    this.map.doubleClickZoom.disable();
    this.renderMeasurement();
  }

  private disableMeasureMode(clear = false) {
    this.measureActive = false;
    this.map.doubleClickZoom.enable();

    if (clear) {
      this.clearMeasurement();
      return;
    }

    this.measureState.previewPoint = null;
    this.renderMeasurement();
  }

  private handleMeasureClick(latlng: L.LatLng) {
    if (!this.measureActive) {
      return;
    }

    if (this.measureState.finished) {
      this.clearMeasurement();
    }

    this.measureState.points = [...this.measureState.points, latlng];
    this.measureState.previewPoint = null;
    this.measureState.finished = false;
    this.measureStarted = true;
    this.renderMeasurement();
  }

  private handleMeasureMouseMove(latlng: L.LatLng) {
    if (!this.measureActive || this.measureState.finished || !this.measureState.points.length) {
      return;
    }

    this.measureState.previewPoint = latlng;
    this.renderMeasurement();
  }

  private finishMeasurement() {
    if (!this.measureActive) {
      return;
    }

    this.measureState.previewPoint = null;
    this.measureState.finished = this.measureState.points.length >= 2;
    this.renderMeasurement();
  }

  private renderMeasurement() {
    this.measureLayer.clearLayers();

    const points = this.measureState.previewPoint
      ? [...this.measureState.points, this.measureState.previewPoint]
      : [...this.measureState.points];

    if (!points.length) {
      this.measureDistanceText = '0 m';
      this.measureStarted = false;
      return;
    }

    this.measureStarted = true;

    for (const point of this.measureState.points) {
      const marker = L.circleMarker(point, {
        radius: 4,
        color: this.MEASURE_STROKE,
        weight: 2,
        fillColor: this.MEASURE_FILL,
        fillOpacity: 0.95,
        renderer: this.vectorRenderer,
      });
      this.measureLayer.addLayer(marker);
    }

    if (points.length >= 2) {
      const polyline = L.polyline(points, {
        color: this.MEASURE_STROKE,
        weight: 3,
        dashArray: '8 6',
        lineCap: 'round',
        renderer: this.vectorRenderer,
      });
      this.measureLayer.addLayer(polyline);
    }

    const totalMeters = this.computeDistance(points);
    this.measureDistanceText = this.formatDistance(totalMeters);

    const lastPoint = points[points.length - 1];
    const label = L.marker(lastPoint, {
      interactive: false,
      icon: this.createMeasureLabelIcon(this.measureDistanceText),
      zIndexOffset: 1500,
    });
    this.measureLayer.addLayer(label);
  }

  private computeDistance(points: L.LatLng[]): number {
    if (!this.map || points.length < 2) {
      return 0;
    }

    let total = 0;

    for (let index = 1; index < points.length; index += 1) {
      total += this.map.distance(points[index - 1], points[index]);
    }

    return total;
  }

  private formatDistance(meters: number): string {
    if (!Number.isFinite(meters) || meters <= 0) {
      return '0 m';
    }

    if (meters < 1000) {
      return `${meters.toFixed(meters < 10 ? 2 : meters < 100 ? 1 : 0)} m`;
    }

    return `${(meters / 1000).toFixed(meters < 10000 ? 2 : 1)} km`;
  }

  private createMeasureLabelIcon(text: string): L.DivIcon {
    return L.divIcon({
      className: 'mapa-measure-label-host',
      html: `<div class="mapa-measure-label">${this.escapeHtml(text)}</div>`,
      iconSize: [0, 0],
      iconAnchor: [0, 0],
    });
  }

  private renderElementosKeepingDraft() {
    const activeId = this.editSession.elementId;
    const dirty = this.editSession.dirty;
    const currentWkt = this.editSession.currentWkt;

    this.renderElementos();

    if (!activeId) return;

    const layer = this.renderedLayers.get(activeId);
    if (!layer) return;

    if (dirty && currentWkt) {
      const draftStyle: ResolvedElementStyle = {
        iconoFuente: null,
        icono: null,
        iconoClase: null,
        colorFill: this.EDIT_FILL,
        colorStroke: this.EDIT_STROKE,
        colorTexto: this.EDIT_STROKE,
        strokeWidth: 3,
        zIndex: 999,
        tamanoIcono: 18,
      };

      const draftLayer = this.layerFromWkt(currentWkt, draftStyle, false);
      if (draftLayer) {
        this.replaceLayerGeometry(layer, draftLayer);
      }
    }

    this.editSession.layer = layer;
    this.enableLayerEditing(layer);
    this.emitEditSessionState();
  }

  private renderElementos() {
    this.drawnItems.clearLayers();
    this.renderedLayers.clear();

    const hiddenSet = new Set(this.hiddenTipoIds);
    const tipoMap = new Map(this.tipos.map((t) => [t.idGeoTipoElemento, t]));

    const candidates = this.elementos.filter((el) => {
      if (hiddenSet.has(el.idGeoTipoElementoFk)) {
        return false;
      }

      return this.shouldRenderElement(el);
    });

    // Precomputar zIndex una sola vez por elemento (antes el sort llamaba resolveElementStyle por comparacion -> O(N log N)).
    const zIndexById = new Map<number, number>();
    for (const el of candidates) {
      const tipo = tipoMap.get(el.idGeoTipoElementoFk) ?? null;
      zIndexById.set(el.idGeoElemento, this.resolveElementStyle(el, tipo).zIndex);
    }
    const renderQueue = candidates.sort((a, b) => {
      return (
        (zIndexById.get(a.idGeoElemento) ?? 0) - (zIndexById.get(b.idGeoElemento) ?? 0) ||
        Number(a.ordenDibujo ?? 0) - Number(b.ordenDibujo ?? 0) ||
        a.idGeoElemento - b.idGeoElemento
      );
    });

    for (const el of renderQueue) {
      const tipo = tipoMap.get(el.idGeoTipoElementoFk) ?? null;
      const layer = this.layerFromElemento(el, tipo);
      if (!layer) continue;

      const outlineLayer = (layer as any).__outlineLayer as L.Layer | undefined;

      (layer as any).__idGeoElemento = el.idGeoElemento;
      (layer as any).__geomTipo = el.geomTipo;
      (layer as any).__elementName = el.nombre ?? '';
      (layer as any).__tooltipBound = true;

      this.bindTooltipForLayer(layer, el);
      this.bindLayerInteraction(layer, el);

      if (outlineLayer) {
        (outlineLayer as any).__idGeoElemento = el.idGeoElemento;
        (outlineLayer as any).__geomTipo = el.geomTipo;
        (outlineLayer as any).__elementName = el.nombre ?? '';
        this.bindLayerInteraction(outlineLayer, el, layer);
        this.drawnItems.addLayer(outlineLayer);
      }

      this.drawnItems.addLayer(layer);
      this.renderedLayers.set(el.idGeoElemento, layer);
    }

    this.applySelectionStyle();
    this.renderVisibleLabels(renderQueue);
    this.syncSelectedTooltip();
  }

  private bindLayerInteraction(
    targetLayer: L.Layer,
    elemento: MapaElemento,
    anchorLayer?: L.Layer
  ) {
    const interactionAnchor = anchorLayer ?? targetLayer;

    targetLayer.off('click');
    targetLayer.off('contextmenu');

    targetLayer.on('click', (ev: any) => {
      if (this.toolMode === 'measure') {
        const latlng = ev?.latlng ?? this.tryGetLayerLatLng(interactionAnchor);
        if (latlng) {
          this.handleMeasureClick(latlng);
        }
        return;
      }

      this.elementoSelected.emit(elemento);
    });

    targetLayer.on('contextmenu', (ev: any) => {
      if (this.toolMode === 'measure') {
        return;
      }

      this.elementoContext.emit({
        elemento,
        x: ev.originalEvent?.clientX ?? 0,
        y: ev.originalEvent?.clientY ?? 0,
      });
    });
  }

  private bindTooltipForLayer(layer: L.Layer, elemento: MapaElemento) {
    const safeName = (elemento.nombre || '').trim();
    if (!safeName) return;

    const anyLayer = layer as any;
    if (typeof anyLayer.bindTooltip !== 'function') {
      return;
    }

    if (typeof anyLayer.unbindTooltip === 'function') {
      anyLayer.unbindTooltip();
    }

    const direction = elemento.geomTipo === 'polygon' ? 'center' : 'top';

    anyLayer.bindTooltip(safeName, {
      direction,
      sticky: false,
      permanent: false,
      opacity: 0.96,
      className: 'mapa-element-tooltip',
    });
  }

  private shouldShowPersistentLabels(): boolean {
    return this.getDynamicLabelBudget() > 0;
  }

  private renderVisibleLabels(renderedElementos: MapaElemento[]) {
    this.labelsLayer.clearLayers();

    if (!this.shouldShowPersistentLabels()) {
      return;
    }

    const viewBounds = this.currentViewBounds;
    if (!viewBounds || !this.map) {
      return;
    }

    const budget = this.getDynamicLabelBudget();
    if (budget <= 0) {
      return;
    }

    const candidates: LabelCandidate[] = [];

    for (const elemento of renderedElementos) {
      const name = (elemento.nombre || '').trim();
      if (!name) {
        continue;
      }

      const layer = this.renderedLayers.get(elemento.idGeoElemento) ?? null;
      if (!layer) {
        continue;
      }

      const anchor = this.getLabelAnchor(layer, elemento);
      if (!anchor || !viewBounds.pad(0.08).contains(anchor)) {
        continue;
      }

      candidates.push({
        elemento,
        layer,
        anchor,
        name,
        selected: elemento.idGeoElemento === this.selectedElementoId,
        priority: this.getLabelPriority(elemento, anchor),
      });
    }

    candidates.sort((a, b) => {
      return (
        b.priority - a.priority ||
        a.name.length - b.name.length ||
        a.elemento.idGeoElemento - b.elemento.idGeoElemento
      );
    });

    const placedBoxes: LabelCollisionBox[] = [];
    let painted = 0;

    for (const candidate of candidates) {
      if (painted >= budget) {
        break;
      }

      const point = this.map.latLngToContainerPoint(candidate.anchor);
      const box = this.estimateLabelCollisionBox(point, candidate.name, candidate.selected);

      if (!this.isLabelBoxInsideViewport(box)) {
        continue;
      }

      if (this.hasLabelCollision(box, placedBoxes)) {
        continue;
      }

      const label = L.marker(candidate.anchor, {
        interactive: false,
        zIndexOffset: candidate.selected ? 1500 : 1200,
        icon: this.createPersistentLabelIcon(candidate.name, candidate.selected),
      });

      this.labelsLayer.addLayer(label);
      placedBoxes.push(box);
      painted += 1;
    }
  }

  private getDynamicLabelBudget(): number {
    if (!this.labelsVisible) {
      return 0;
    }

    const zoom = this.currentZoom;

    if (zoom < this.LABELS_MIN_ZOOM) {
      return 0;
    }

    if (this.performanceModeEnabled) {
      if (zoom < 13) return 10;
      if (zoom < 14) return 16;
      if (zoom < 15) return 24;
      if (zoom < 16) return 32;
      if (zoom < 17) return 40;
      return this.LABELS_PERFORMANCE_MAX_VISIBLE;
    }

    if (zoom < 13) return 18;
    if (zoom < 14) return 30;
    if (zoom < 15) return 46;
    if (zoom < 16) return 64;
    if (zoom < 17) return 88;
    return this.LABELS_MAX_VISIBLE;
  }

  private getLabelPriority(elemento: MapaElemento, _anchor: L.LatLng): number {
    let score = 0;

    if (elemento.idGeoElemento === this.selectedElementoId) {
      score += 1000;
    }

    if (elemento.geomTipo === 'polygon') {
      score += 60;
    } else if (elemento.geomTipo === 'linestring') {
      score += 40;
    } else {
      score += 20;
    }

    const drawOrder = Number(elemento.ordenDibujo ?? 0);
    score += Math.max(0, drawOrder);

    return score;
  }

  private estimateLabelCollisionBox(
    point: L.Point,
    text: string,
    selected: boolean
  ): LabelCollisionBox {
    const zoom = this.currentZoom;
    const charWidth = zoom >= 16 ? 6.3 : zoom >= 15 ? 5.6 : 4.9;
    const width = Math.min(180, Math.max(52, text.length * charWidth + 16 + (selected ? 8 : 0)));
    const height = selected ? 28 : 24;

    return {
      left: point.x - width / 2,
      right: point.x + width / 2,
      top: point.y - height - 12,
      bottom: point.y - 4,
    };
  }

  private isLabelBoxInsideViewport(box: LabelCollisionBox): boolean {
    const size = this.map.getSize();
    return (
      box.right >= 0 &&
      box.left <= size.x &&
      box.bottom >= 0 &&
      box.top <= size.y
    );
  }

  private hasLabelCollision(box: LabelCollisionBox, placed: LabelCollisionBox[]): boolean {
    for (const current of placed) {
      const separated =
        box.right < current.left ||
        box.left > current.right ||
        box.bottom < current.top ||
        box.top > current.bottom;

      if (!separated) {
        return true;
      }
    }

    return false;
  }

  private getLabelAnchor(layer: L.Layer, elemento: MapaElemento): L.LatLng | null {
    if (elemento.geomTipo === 'point') {
      return this.tryGetLayerLatLng(layer);
    }

    const anyLayer = layer as any;
    if (typeof anyLayer.getBounds === 'function') {
      const bounds = anyLayer.getBounds();
      if (bounds?.isValid?.()) {
        return bounds.getCenter();
      }
    }

    return this.tryGetLayerLatLng(layer);
  }

  private createPersistentLabelIcon(text: string, selected = false): L.DivIcon {
    return L.divIcon({
      className: 'mapa-element-label-host',
      html: `<div class="mapa-element-label${selected ? ' is-selected' : ''}">${this.escapeHtml(text)}</div>`,
      iconSize: [0, 0],
      iconAnchor: [0, 0],
    });
  }

  private openTooltipForLayer(layer: L.Layer | null) {
    if (!layer) return;
    const anyLayer = layer as any;
    if (typeof anyLayer.openTooltip === 'function') {
      anyLayer.openTooltip();
    }
  }

  private closeTooltipForLayer(layer: L.Layer | null) {
    if (!layer) return;
    const anyLayer = layer as any;
    if (typeof anyLayer.closeTooltip === 'function') {
      anyLayer.closeTooltip();
    }
  }

  private syncSelectedTooltip() {
    const selectedId = this.selectedElementoId ?? null;

    if (selectedId === this.lastTooltipOpenedElementoId) {
      return;
    }

    if (this.lastTooltipOpenedElementoId != null) {
      this.closeTooltipForLayer(this.renderedLayers.get(this.lastTooltipOpenedElementoId) ?? null);
    }

    this.lastTooltipOpenedElementoId = selectedId;

    if (selectedId == null) {
      return;
    }

    this.openTooltipForLayer(this.renderedLayers.get(selectedId) ?? null);
  }

  private shouldRenderElement(el: MapaElemento): boolean {
    if (!this.performanceModeEnabled) {
      return true;
    }

    if (this.selectedElementoId === el.idGeoElemento) {
      return true;
    }

    if (this.editSession.active && this.editSession.elementId === el.idGeoElemento) {
      return true;
    }

    const geomTipo = String(el.geomTipo ?? '').toLowerCase();

    if (geomTipo !== 'point') {
      return true;
    }

    const viewBounds = this.currentViewBounds;
    if (!viewBounds) {
      return true;
    }

    const elementBounds = this.getElementBounds(el);
    if (!elementBounds?.isValid?.()) {
      return true;
    }

    return viewBounds.pad(this.VIEWPORT_PAD_FACTOR).intersects(elementBounds);
  }

  private getElementBounds(el: MapaElemento): L.LatLngBounds | null {
    const signature = this.getElementSignature(el);
    const cached = this.elementBoundsCache.get(el.idGeoElemento);

    if (cached && cached.signature === signature) {
      return cached.bounds;
    }

    const bounds = this.computeElementBounds(el);
    this.elementBoundsCache.set(el.idGeoElemento, { signature, bounds });

    return bounds;
  }

  private getElementSignature(el: MapaElemento): string {
    const geom = el.geometria;
    const wkt = typeof (el as any).wkt === 'string' ? String((el as any).wkt) : '';
    const rawGeom =
      typeof geom === 'string'
        ? geom
        : geom != null
          ? JSON.stringify(geom)
          : '';

    return `${el.idGeoElemento}|${el.geomTipo ?? ''}|${wkt}|${rawGeom}`;
  }

  private computeElementBounds(el: MapaElemento): L.LatLngBounds | null {
    const geom = el.geometria;

    if (geom && typeof geom === 'object' && (geom as any).type && (geom as any).coordinates) {
      return this.boundsFromGeoJsonGeometry(geom as any);
    }

    if (geom) {
      const embeddedWkt = this.tryExtractWkt(geom);
      if (embeddedWkt) {
        return this.boundsFromWkt(embeddedWkt);
      }
    }

    if (typeof (el as any).wkt === 'string' && (el as any).wkt.trim()) {
      return this.boundsFromWkt((el as any).wkt);
    }

    return null;
  }

  private boundsFromGeoJsonGeometry(geom: any): L.LatLngBounds | null {
    const type = String(geom.type || '').toLowerCase();
    const coords = geom.coordinates;

    if (type === 'point' && Array.isArray(coords) && coords.length >= 2) {
      const ll = L.latLng(Number(coords[1]), Number(coords[0]));
      return L.latLngBounds([ll, ll]);
    }

    return this.boundsFromCoordinates(coords);
  }

  private boundsFromCoordinates(coords: any): L.LatLngBounds | null {
    const points: L.LatLng[] = [];
    this.collectCoordinatePoints(coords, points);

    if (!points.length) {
      return null;
    }

    return L.latLngBounds(points);
  }

  private collectCoordinatePoints(value: any, out: L.LatLng[]) {
    if (!Array.isArray(value)) {
      return;
    }

    if (
      value.length >= 2 &&
      typeof value[0] === 'number' &&
      typeof value[1] === 'number'
    ) {
      out.push(L.latLng(Number(value[1]), Number(value[0])));
      return;
    }

    for (const item of value) {
      this.collectCoordinatePoints(item, out);
    }
  }

  private boundsFromWkt(wkt: string): L.LatLngBounds | null {
    const parsed = parseWktGeometry(wkt);
    if (!parsed) return null;

    if (parsed.renderType === 'point' && parsed.point) {
      const ll = L.latLng(parsed.point[0], parsed.point[1]);
      return L.latLngBounds([ll, ll]);
    }

    if (parsed.renderType === 'polyline' && parsed.line?.length) {
      return L.latLngBounds(parsed.line);
    }

    if (parsed.renderType === 'polygon' && parsed.polygon?.length) {
      return this.boundsFromLatLngCollections(parsed.polygon as any);
    }

    return null;
  }

  private boundsFromLatLngCollections(value: any): L.LatLngBounds | null {
    const points: L.LatLng[] = [];
    this.collectLatLngPoints(value, points);

    if (!points.length) {
      return null;
    }

    return L.latLngBounds(points);
  }

  private collectLatLngPoints(value: any, out: L.LatLng[]) {
    if (!Array.isArray(value)) {
      return;
    }

    if (value.length && this.isLatLng(value[0])) {
      for (const point of value as L.LatLng[]) {
        out.push(point);
      }
      return;
    }

    for (const item of value) {
      this.collectLatLngPoints(item, out);
    }
  }

  private applySelectionStyle() {
    for (const [id, layer] of this.renderedLayers.entries()) {
      const isSelected = id === this.selectedElementoId;
      const anyLayer = layer as any;
      const outlineLayer = anyLayer.__outlineLayer as L.Layer | undefined;

      const baseWeight =
        typeof anyLayer.__baseWeight === 'number' ? Number(anyLayer.__baseWeight) : 3;
      const baseFillOpacity =
        typeof anyLayer.__baseFillOpacity === 'number'
          ? Number(anyLayer.__baseFillOpacity)
          : 0.15;
      const baseZIndex =
        typeof anyLayer.__baseZIndex === 'number' ? Number(anyLayer.__baseZIndex) : 0;
      const baseRadius =
        typeof anyLayer.__baseRadius === 'number'
          ? Number(anyLayer.__baseRadius)
          : this.PERFORMANCE_POINT_RADIUS;
      const baseOutlineWeight =
        typeof anyLayer.__baseOutlineWeight === 'number'
          ? Number(anyLayer.__baseOutlineWeight)
          : Math.max(baseWeight + 2, baseWeight * 1.8);

      if (outlineLayer && typeof (outlineLayer as any).setStyle === 'function') {
        (outlineLayer as any).setStyle({
          weight: isSelected ? Math.max(baseOutlineWeight + 2, baseOutlineWeight * 1.1) : baseOutlineWeight,
          opacity: isSelected ? 1 : 0.96,
          dashArray: undefined,
        });
      }

      if (typeof anyLayer.setStyle === 'function') {
        anyLayer.setStyle({
          weight: isSelected ? Math.max(baseWeight + 1, baseWeight * 1.25) : baseWeight,
          opacity: isSelected ? 1 : 0.92,
          fillOpacity: isSelected ? Math.max(baseFillOpacity, 0.36) : baseFillOpacity,
          dashArray: isSelected ? '8 6' : undefined,
        });
      }

      if (typeof anyLayer.setRadius === 'function') {
        anyLayer.setRadius(isSelected ? Math.max(baseRadius + 3, 9) : baseRadius);
      }

      if (typeof anyLayer.setZIndexOffset === 'function') {
        anyLayer.setZIndexOffset(baseZIndex + (isSelected ? 2000 : 0));
      }

      const element = this.tryGetMarkerElement(layer);
      if (element) {
        element.classList.toggle('is-selected', isSelected);
      }

      if (isSelected) {
        if (outlineLayer && typeof (outlineLayer as any).bringToFront === 'function') {
          (outlineLayer as any).bringToFront();
        }
        if (typeof anyLayer.bringToFront === 'function') {
          anyLayer.bringToFront();
        }
      } else if (typeof anyLayer.closeTooltip === 'function') {
        anyLayer.closeTooltip();
      }
    }
  }

  private tryGetMarkerElement(layer: L.Layer): HTMLElement | null {
    const anyLayer = layer as any;
    if (typeof anyLayer.getElement === 'function') {
      return anyLayer.getElement() as HTMLElement | null;
    }
    return null;
  }

  private tryGetLayerLatLng(layer: L.Layer): L.LatLng | null {
    const anyLayer = layer as any;

    if (typeof anyLayer.getLatLng === 'function') {
      return anyLayer.getLatLng() as L.LatLng;
    }

    if (typeof anyLayer.getBounds === 'function') {
      const bounds = anyLayer.getBounds();
      if (bounds?.isValid?.()) {
        return bounds.getCenter();
      }
    }

    return null;
  }

  private layerFromElemento(
    el: MapaElemento,
    tipo: MapaTipoElemento | null
  ): L.Layer | null {
    const geom = el.geometria;
    const style = this.resolveElementStyle(el, tipo);

    const simplifyPoint = this.shouldSimplifyPoint(el);

    if (geom && typeof geom === 'object' && (geom as any).type && (geom as any).coordinates) {
      const fromGeoJson = this.layerFromGeoJsonGeometry(geom, style, simplifyPoint);
      if (fromGeoJson) return fromGeoJson;
    }

    if (geom) {
      const embeddedWkt = this.tryExtractWkt(geom);
      if (embeddedWkt) {
        return this.layerFromWkt(embeddedWkt, style, simplifyPoint);
      }
    }

    if ((el as any).wkt) {
      return this.layerFromWkt((el as any).wkt, style, simplifyPoint);
    }

    return null;
  }

  private shouldSimplifyPoint(el: MapaElemento): boolean {
    if (!this.performanceModeEnabled) return false;
    if (this.currentZoom >= this.SIMPLIFY_POINTS_BELOW_ZOOM) return false;
    if (this.selectedElementoId === el.idGeoElemento) return false;
    if (this.editSession.active && this.editSession.elementId === el.idGeoElemento) return false;

    const geomTipo = String(el.geomTipo ?? '').toLowerCase();
    return geomTipo === 'point';
  }

  private layerFromGeoJsonGeometry(
    geom: any,
    style: ResolvedElementStyle,
    simplifyPoint = false
  ): L.Layer | null {
    const type = String(geom.type || '').toLowerCase();
    const coords = geom.coordinates;

    if (type === 'point' && Array.isArray(coords) && coords.length >= 2) {
      return this.createPointLayer(
        L.latLng(Number(coords[1]), Number(coords[0])),
        style,
        simplifyPoint
      );
    }

    if (type === 'linestring' && Array.isArray(coords)) {
      return this.createLineLayer(
        coords.map((pair: number[]) => [Number(pair[1]), Number(pair[0])] as [number, number]),
        style
      );
    }

    if (type === 'multilinestring' && Array.isArray(coords) && Array.isArray(coords[0])) {
      return this.createLineLayer(
        coords.map((line: number[][]) =>
          line.map((pair: number[]) => [Number(pair[1]), Number(pair[0])] as [number, number])
        ),
        style
      );
    }

    if (type === 'polygon' && Array.isArray(coords) && Array.isArray(coords[0])) {
      const layer = L.polygon(
        coords.map((ring: number[][]) =>
          ring.map((pair: number[]) => [Number(pair[1]), Number(pair[0])] as [number, number])
        ),
        {
          color: style.colorStroke,
          weight: style.strokeWidth,
          lineCap: 'round',
          lineJoin: 'round',
          fillColor: style.colorFill,
          fillOpacity: 0.15,
          renderer: this.vectorRenderer,
        }
      );

      (layer as any).__baseWeight = style.strokeWidth;
      (layer as any).__baseFillOpacity = 0.15;
      (layer as any).__baseZIndex = style.zIndex;

      return layer;
    }

    if (
      type === 'multipolygon' &&
      Array.isArray(coords) &&
      Array.isArray(coords[0]) &&
      Array.isArray(coords[0][0])
    ) {
      const layer = L.polygon(
        coords.map((polygon: number[][][]) =>
          polygon.map((ring: number[][]) =>
            ring.map((pair: number[]) => [Number(pair[1]), Number(pair[0])] as [number, number])
          )
        ),
        {
          color: style.colorStroke,
          weight: style.strokeWidth,
          lineCap: 'round',
          lineJoin: 'round',
          fillColor: style.colorFill,
          fillOpacity: 0.15,
          renderer: this.vectorRenderer,
        }
      );

      (layer as any).__baseWeight = style.strokeWidth;
      (layer as any).__baseFillOpacity = 0.15;
      (layer as any).__baseZIndex = style.zIndex;

      return layer;
    }

    return null;
  }

  private tryExtractWkt(geom: any): string | null {
    if (typeof geom === 'string') return geom;
    if (geom && typeof geom === 'object' && typeof geom.wkt === 'string') return geom.wkt;
    return null;
  }

  private layerFromWkt(
    wkt: string,
    style: ResolvedElementStyle,
    simplifyPoint = false
  ): L.Layer | null {
    const parsed = parseWktGeometry(wkt);
    if (!parsed) return null;

    if (parsed.renderType === 'point' && parsed.point) {
      return this.createPointLayer(
        L.latLng(parsed.point[0], parsed.point[1]),
        style,
        simplifyPoint
      );
    }

    if (parsed.renderType === 'polyline' && parsed.line) {
      return this.createLineLayer(parsed.line, style);
    }

    if (parsed.renderType === 'polygon' && parsed.polygon) {
      const layer = L.polygon(parsed.polygon, {
        color: style.colorStroke,
        weight: style.strokeWidth,
        fillColor: style.colorFill,
        fillOpacity: 0.15,
        renderer: this.vectorRenderer,
      });

      (layer as any).__baseWeight = style.strokeWidth;
      (layer as any).__baseFillOpacity = 0.15;
      (layer as any).__baseZIndex = style.zIndex;

      return layer;
    }

    return null;
  }

  private createLineLayer(latlngs: any, style: ResolvedElementStyle): L.Layer {
    const innerWeight = Math.max(1, style.strokeWidth);
    const outlineWeight = Math.max(innerWeight + 2, Math.round(innerWeight * 1.8));
    const outline = L.polyline(latlngs, {
      color: style.colorStroke,
      weight: outlineWeight,
      opacity: 0.96,
      lineCap: 'round',
      lineJoin: 'round',
      interactive: true,
      renderer: this.vectorRenderer,
    });

    const line = L.polyline(latlngs, {
      color: style.colorFill,
      weight: innerWeight,
      lineCap: 'round',
      lineJoin: 'round',
      renderer: this.vectorRenderer,
    });

    (line as any).__outlineLayer = outline;
    (line as any).__baseWeight = innerWeight;
    (line as any).__baseOutlineWeight = outlineWeight;
    (line as any).__baseFillOpacity = 0;
    (line as any).__baseZIndex = style.zIndex;

    return line;
  }

  private geomTipoFromLayerType(layerType: string): MapaGeomTipo {
    if (layerType === 'marker') return 'point';
    if (layerType === 'polyline') return 'linestring';
    return 'polygon';
  }

  private inferGeomTipoFromLayer(layer: L.Layer): MapaGeomTipo {
    const anyLayer = layer as any;

    if (typeof anyLayer.getLatLng === 'function') {
      return 'point';
    }

    if (anyLayer instanceof L.Polygon) {
      return 'polygon';
    }

    if (anyLayer instanceof L.Polyline) {
      return 'linestring';
    }

    if (typeof anyLayer.getLatLngs === 'function') {
      return 'linestring';
    }

    return 'point';
  }

  private isLatLng(value: any): value is L.LatLng {
    return !!value && typeof value.lat === 'number' && typeof value.lng === 'number';
  }

  private layerToWkt(layer: L.Layer, geomTipo: MapaGeomTipo): string | null {
    const anyLayer = layer as any;

    if (geomTipo === 'point' && typeof anyLayer.getLatLng === 'function') {
      const ll = anyLayer.getLatLng();
      return `POINT(${ll.lng} ${ll.lat})`;
    }

    if (geomTipo === 'linestring' && typeof anyLayer.getLatLngs === 'function') {
      const latlngs = anyLayer.getLatLngs() as any[];

      if (Array.isArray(latlngs[0])) {
        const parts = (latlngs as L.LatLng[][])
          .filter((part) => Array.isArray(part) && part.length > 0)
          .map((part) => `(${part.map((p) => `${p.lng} ${p.lat}`).join(', ')})`)
          .join(', ');

        return parts ? `MULTILINESTRING(${parts})` : null;
      }

      const coords = (latlngs as L.LatLng[]).map((p) => `${p.lng} ${p.lat}`).join(', ');
      return `LINESTRING(${coords})`;
    }

    if (geomTipo === 'polygon' && typeof anyLayer.getLatLngs === 'function') {
      const groups = anyLayer.getLatLngs() as any;

      if (
        Array.isArray(groups) &&
        Array.isArray(groups[0]) &&
        Array.isArray(groups[0][0]) &&
        groups[0][0].length > 0 &&
        this.isLatLng(groups[0][0][0])
      ) {
        const multiPolygonText = (groups as L.LatLng[][][])
          .filter((polygon) => Array.isArray(polygon) && polygon.length > 0)
          .map((polygon) => {
            const ringText = polygon
              .filter((ring) => Array.isArray(ring) && ring.length > 0)
              .map((ring) => {
                const closed =
                  ring[0].lat === ring[ring.length - 1].lat &&
                    ring[0].lng === ring[ring.length - 1].lng
                    ? ring
                    : [...ring, ring[0]];

                return `(${closed.map((p) => `${p.lng} ${p.lat}`).join(', ')})`;
              })
              .join(', ');

            return `(${ringText})`;
          })
          .join(', ');

        return multiPolygonText ? `MULTIPOLYGON(${multiPolygonText})` : null;
      }

      let rings: L.LatLng[][] = [];

      if (Array.isArray(groups) && groups.length > 0 && this.isLatLng(groups[0])) {
        rings = [groups as L.LatLng[]];
      } else if (
        Array.isArray(groups) &&
        Array.isArray(groups[0]) &&
        (groups[0].length === 0 || this.isLatLng(groups[0][0]))
      ) {
        rings = groups as L.LatLng[][];
      } else if (
        Array.isArray(groups) &&
        Array.isArray(groups[0]) &&
        Array.isArray(groups[0][0])
      ) {
        rings = groups[0] as L.LatLng[][];
      }

      if (!rings.length) return null;

      const ringText = rings
        .filter((ring) => Array.isArray(ring) && ring.length > 0)
        .map((ring) => {
          const closed =
            ring[0].lat === ring[ring.length - 1].lat &&
              ring[0].lng === ring[ring.length - 1].lng
              ? ring
              : [...ring, ring[0]];

          return `(${closed.map((p) => `${p.lng} ${p.lat}`).join(', ')})`;
        })
        .join(', ');

      return ringText ? `POLYGON(${ringText})` : null;
    }

    return null;
  }

  private cloneLayer(layer: L.Layer): L.Layer | null {
    const geomTipo = this.inferGeomTipoFromLayer(layer);
    const wkt = this.layerToWkt(layer, geomTipo);
    if (!wkt) return null;

    const draftStyle: ResolvedElementStyle = {
      iconoFuente: null,
      icono: null,
      iconoClase: null,
      colorFill: this.EDIT_FILL,
      colorStroke: this.EDIT_STROKE,
      colorTexto: this.EDIT_STROKE,
      strokeWidth: 3,
      zIndex: 999,
      tamanoIcono: 18,
    };

    return this.layerFromWkt(wkt, draftStyle, false);
  }

  private replaceLayerGeometry(target: L.Layer, source: L.Layer) {
    const targetAny = target as any;
    const sourceAny = source as any;

    if (typeof targetAny.setLatLng === 'function' && typeof sourceAny.getLatLng === 'function') {
      targetAny.setLatLng(sourceAny.getLatLng());
      targetAny.update?.();
      return;
    }

    if (typeof targetAny.setLatLngs === 'function' && typeof sourceAny.getLatLngs === 'function') {
      targetAny.setLatLngs(sourceAny.getLatLngs());
      targetAny.redraw?.();
    }

    const targetOutline = targetAny.__outlineLayer as any;
    const sourceOutline = sourceAny.__outlineLayer as any;

    if (
      targetOutline &&
      sourceOutline &&
      typeof targetOutline.setLatLngs === 'function' &&
      typeof sourceOutline.getLatLngs === 'function'
    ) {
      targetOutline.setLatLngs(sourceOutline.getLatLngs());
      targetOutline.redraw?.();
    }
  }

  private createPointLayer(
    latlng: L.LatLng,
    style: ResolvedElementStyle,
    simplifyPoint = false
  ): L.Layer {
    if (simplifyPoint) {
      const radius = Math.max(
        this.PERFORMANCE_POINT_RADIUS,
        Math.min(10, Math.round(style.tamanoIcono * 0.28))
      );

      const layer = L.circleMarker(latlng, {
        radius,
        color: style.colorStroke,
        weight: Math.max(1, Math.min(5, style.strokeWidth)),
        fillColor: style.colorFill,
        fillOpacity: 0.88,
        renderer: this.vectorRenderer,
      });

      (layer as any).__baseWeight = Math.max(1, Math.min(5, style.strokeWidth));
      (layer as any).__baseFillOpacity = 0.88;
      (layer as any).__baseZIndex = style.zIndex;
      (layer as any).__baseRadius = radius;

      return layer;
    }

    const iconSource = this.normalizeIconSource(style.iconoFuente);
    const iconValue = (style.icono || '').trim();
    const iconClassValue = (style.iconoClase || '').trim();
    const size = style.tamanoIcono;
    const stroke = style.colorStroke;
    const fill = style.colorFill;
    const textColor = style.colorTexto || stroke;

    if (this.isUrlIcon(iconSource, iconValue)) {
      const icon = L.icon({
        iconUrl: iconValue,
        iconSize: [size, size],
        iconAnchor: [Math.round(size / 2), Math.round(size / 2)],
        className: 'mapa-url-icon',
      });

      const marker = L.marker(latlng, { icon, draggable: false });
      marker.setZIndexOffset(style.zIndex);

      (marker as any).__baseZIndex = style.zIndex;
      return marker;
    }

    if (this.isMaterialSymbol(iconSource)) {
      const familyClass = this.resolveMaterialFamily(iconSource);
      const weightAxis = this.toMaterialSymbolWeight(style.strokeWidth);
      const fillAxis = fill && fill !== 'transparent' ? 1 : 0;
      const glyph = this.escapeHtml(iconValue || 'radio_button_checked');

      const icon = L.divIcon({
        className: 'mapa-div-icon',
        html: `
        <div class="mapa-point-icon-shell" style="
          width:${size}px;
          height:${size}px;
          color:${textColor};
        ">
          <span
            class="${familyClass}"
            style="
              font-size:${size}px;
              line-height:1;
              font-variation-settings:'FILL' ${fillAxis}, 'wght' ${weightAxis}, 'GRAD' 0, 'opsz' ${Math.max(20, Math.round(size))};
            "
          >${glyph}</span>
        </div>
      `,
        iconSize: [size, size],
        iconAnchor: [Math.round(size / 2), Math.round(size / 2)],
      });

      const marker = L.marker(latlng, { icon, draggable: false });
      marker.setZIndexOffset(style.zIndex);

      (marker as any).__baseZIndex = style.zIndex;
      return marker;
    }

    if (this.isCssClassIcon(iconSource, iconClassValue || iconValue)) {
      const classValue = this.escapeHtmlAttr(iconClassValue || iconValue);

      const icon = L.divIcon({
        className: 'mapa-div-icon',
        html: `
        <div class="mapa-point-icon-shell" style="
          width:${size}px;
          height:${size}px;
          color:${textColor};
          font-size:${size}px;
          line-height:1;
        ">
          <i class="${classValue}"></i>
        </div>
      `,
        iconSize: [size, size],
        iconAnchor: [Math.round(size / 2), Math.round(size / 2)],
      });

      const marker = L.marker(latlng, { icon, draggable: false });
      marker.setZIndexOffset(style.zIndex);

      (marker as any).__baseZIndex = style.zIndex;
      return marker;
    }

    if (iconSource.includes('triangle')) {
      const half = Math.max(6, Math.round(size * 0.5));
      const icon = L.divIcon({
        className: 'mapa-div-icon',
        html: `
        <div class="mapa-point-icon-shell" style="
          width:${size}px;
          height:${size}px;
          display:flex;
          align-items:center;
          justify-content:center;
        ">
          <div style="
            width:0;
            height:0;
            border-left:${half}px solid transparent;
            border-right:${half}px solid transparent;
            border-bottom:${size}px solid ${fill};
            filter: drop-shadow(0 0 1px ${stroke});
          "></div>
        </div>
      `,
        iconSize: [size, size],
        iconAnchor: [Math.round(size / 2), Math.round(size * 0.85)],
      });

      const marker = L.marker(latlng, { icon, draggable: false });
      marker.setZIndexOffset(style.zIndex);

      (marker as any).__baseZIndex = style.zIndex;
      return marker;
    }

    if (iconSource.includes('target')) {
      const border = Math.max(2, Math.round(style.strokeWidth));
      const inner = Math.max(2, Math.round(size * 0.18));

      const icon = L.divIcon({
        className: 'mapa-div-icon',
        html: `
        <div class="mapa-point-icon-shell" style="
          width:${size}px;
          height:${size}px;
          border:${border}px solid ${stroke};
          border-radius:999px;
          background:${fill};
          box-shadow: inset 0 0 0 ${inner}px white;
        "></div>
      `,
        iconSize: [size, size],
        iconAnchor: [Math.round(size / 2), Math.round(size / 2)],
      });

      const marker = L.marker(latlng, { icon, draggable: false });
      marker.setZIndexOffset(style.zIndex);

      (marker as any).__baseZIndex = style.zIndex;
      return marker;
    }

    if (iconSource.includes('donut')) {
      const border = Math.max(3, Math.round(size * 0.22));

      const icon = L.divIcon({
        className: 'mapa-div-icon',
        html: `
        <div class="mapa-point-icon-shell" style="
          width:${size}px;
          height:${size}px;
          border:${border}px solid ${stroke};
          border-radius:999px;
          background:transparent;
        "></div>
      `,
        iconSize: [size, size],
        iconAnchor: [Math.round(size / 2), Math.round(size / 2)],
      });

      const marker = L.marker(latlng, { icon, draggable: false });
      marker.setZIndexOffset(style.zIndex);

      (marker as any).__baseZIndex = style.zIndex;
      return marker;
    }

    const border = Math.max(2, Math.round(style.strokeWidth));

    const icon = L.divIcon({
      className: 'mapa-div-icon',
      html: `
      <div class="mapa-point-icon-shell" style="
        width:${size}px;
        height:${size}px;
        border-radius:999px;
        background:${fill};
        border:${border}px solid ${stroke};
        box-shadow: 0 0 0 1px rgba(255,255,255,0.8);
      "></div>
    `,
      iconSize: [size, size],
      iconAnchor: [Math.round(size / 2), Math.round(size / 2)],
    });

    const marker = L.marker(latlng, { icon, draggable: false });
    marker.setZIndexOffset(style.zIndex);

    (marker as any).__baseZIndex = style.zIndex;
    return marker;
  }

  private resolveElementStyle(
    el: MapaElemento,
    tipo: MapaTipoElemento | null
  ): ResolvedElementStyle {
    const colorFill = normalizeMapaColorOrDefault(
      el.colorFill || tipo?.colorFill || el.colorStroke || tipo?.colorStroke || null,
      this.DEFAULT_FILL
    );
    const colorStroke = normalizeMapaColorOrDefault(
      el.colorStroke || tipo?.colorStroke || el.colorFill || tipo?.colorFill || null,
      this.DEFAULT_STROKE
    );
    const colorTexto = normalizeMapaColor(
      el.colorTexto || tipo?.colorTexto || el.colorStroke || tipo?.colorStroke || null,
      colorStroke
    );

    return {
      iconoFuente: el.iconoFuente || tipo?.iconoFuente || null,
      icono: el.icono || tipo?.icono || null,
      iconoClase: el.iconoClase || tipo?.iconoClase || null,
      colorFill,
      colorStroke,
      colorTexto,
      strokeWidth: this.normalizeStrokeWidth(el.strokeWidth ?? tipo?.strokeWidth ?? null),
      zIndex: this.normalizeZIndex(el.zIndex ?? tipo?.zIndex ?? null),
      tamanoIcono: this.normalizeIconSize(el.tamanoIcono ?? tipo?.tamanoIcono ?? null),
    };
  }

  private normalizeStrokeWidth(value: number | null | undefined): number {
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return 3;
    return Math.max(1, Math.min(12, n));
  }

  private normalizeZIndex(value: number | null | undefined): number {
    const n = Number(value);
    if (!Number.isFinite(n)) return 0;
    return Math.round(n);
  }

  private normalizeIconSize(value: number | null | undefined): number {
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return 18;
    return Math.max(12, Math.min(64, Math.round(n)));
  }

  private normalizeIconSource(value: string | null | undefined): string {
    return (value || '').trim().toLowerCase();
  }

  private isMaterialSymbol(iconSource: string): boolean {
    return (
      iconSource.includes('material-symbols') ||
      iconSource.includes('material symbols') ||
      iconSource === 'google' ||
      iconSource === 'google-icons'
    );
  }

  private isCssClassIcon(iconSource: string, value: string): boolean {
    if (!value) return false;

    return (
      iconSource === 'class' ||
      iconSource === 'css' ||
      iconSource === 'primeicons' ||
      iconSource === 'fontawesome' ||
      iconSource === 'fa' ||
      iconSource === 'mdi' ||
      iconSource === 'bootstrap-icons'
    );
  }

  private isUrlIcon(iconSource: string, value: string): boolean {
    if (!value) return false;

    return (
      iconSource === 'url' ||
      iconSource === 'image' ||
      iconSource === 'img' ||
      /^https?:\/\//i.test(value) ||
      /^data:image\//i.test(value) ||
      /^\/assets\//i.test(value)
    );
  }

  private resolveMaterialFamily(iconSource: string): string {
    if (iconSource.includes('rounded')) return 'material-symbols-rounded';
    if (iconSource.includes('sharp')) return 'material-symbols-sharp';
    return 'material-symbols-outlined';
  }

  private toMaterialSymbolWeight(strokeWidth: number): number {
    const raw = strokeWidth > 10 ? strokeWidth : strokeWidth * 100;
    const snapped = Math.round(raw / 100) * 100;
    return Math.max(100, Math.min(700, snapped));
  }

  private renderSearchResult(result: MapaGeoSearchResult) {
    this.searchLayer.clearLayers();

    const latlng = L.latLng(result.lat, result.lng);

    if (result.bounds) {
      const rectangle = L.rectangle(
        [
          [result.bounds.south, result.bounds.west],
          [result.bounds.north, result.bounds.east],
        ],
        {
          color: '#2563eb',
          weight: 2,
          opacity: 0.9,
          fillColor: '#60a5fa',
          fillOpacity: 0.08,
          dashArray: '8 6',
          interactive: false,
          bubblingMouseEvents: false,
          renderer: this.vectorRenderer,
        }
      );
      this.searchLayer.addLayer(rectangle);
    }

    const halo = L.circleMarker(latlng, {
      radius: 16,
      color: '#2563eb',
      weight: 2,
      fillColor: '#93c5fd',
      fillOpacity: 0.18,
      interactive: false,
      bubblingMouseEvents: false,
      renderer: this.vectorRenderer,
    });

    const marker = L.marker(latlng, {
      zIndexOffset: 2200,
      icon: this.createSearchMarkerIcon(),
    });

    marker.bindTooltip(result.label, {
      permanent: false,
      direction: 'top',
      opacity: 0.98,
      className: 'mapa-search-result-tooltip',
      offset: L.point(0, -12),
    });

    this.searchLayer.addLayer(halo);
    this.searchLayer.addLayer(marker);
    marker.openTooltip();
  }

  private createSearchMarkerIcon(): L.DivIcon {
    return L.divIcon({
      className: 'mapa-search-marker-host',
      html: `
        <div class="mapa-search-marker">
          <span class="mapa-search-marker-core"></span>
        </div>
      `,
      iconSize: [26, 26],
      iconAnchor: [13, 13],
    });
  }

  private escapeHtml(value: string): string {
    return value
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  private escapeHtmlAttr(value: string): string {
    return this.escapeHtml(value);
  }
}
