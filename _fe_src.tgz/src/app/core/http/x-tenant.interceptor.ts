import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { SessionStore } from 'src/app/features/seg/store/session.store';
import { SKIP_TENANT } from './http-context.tokens';
import { ENVIRONMENT, AppEnvironment } from '@core/config/environment.token';

function shouldSkipByUrl(url: string) {
  return url.includes('/api/aut/');
}

export const xTenantInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.context.get(SKIP_TENANT)) return next(req);
  if (shouldSkipByUrl(req.url)) return next(req);

  const env = inject<AppEnvironment>(ENVIRONMENT);
  const sessionStore = inject(SessionStore);

  const session = sessionStore.session();

  const companyToSend = session?.meta?.company ?? env.company ?? null;
  const tenantToSend = session?.meta?.tenant ?? env.tenant ?? null;

  if (req.headers.has('X-Company') && req.headers.has('X-Tenant')) {
    return next(req);
  }

  const headers: Record<string, string> = {};

  if (!req.headers.has('X-Company') && companyToSend) {
    headers['X-Company'] = companyToSend;
  }

  if (!req.headers.has('X-Tenant') && tenantToSend) {
    headers['X-Tenant'] = tenantToSend;
  }

  if (!Object.keys(headers).length) {
    return next(req);
  }

  return next(req.clone({ setHeaders: headers }));
};
