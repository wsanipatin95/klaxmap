import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
  computed,
  inject,
  signal,
} from '@angular/core';

import type {
  MapaElemento,
  MapaGeomTipo,
  MapaNodo,
  MapaTipoElemento,
} from '../../data-access/mapa.models';
import {
  getAncestorNodeIds,
  getBranchNodeIds,
  getRootNodeIds,
  isNodeHidden,
  sortNodes,
} from '../../utils/mapa-visibility.utils';
import {
  MapaItemVisualPreview,
  previewClassForVisual,
  previewImageUrlForVisual,
  previewMaterialFamilyForVisual,
  previewMaterialGlyphForVisual,
  previewShapeClassForVisual,
  previewStyleForVisual,
  resolveMapaElementoVisual,
  showClassPreviewForVisual,
  showMaterialPreviewForVisual,
  showUrlPreviewForVisual,
} from '../../utils/mapa-element-visual.utils';
import { SessionStore } from '../../../seg/store/session.store';

interface TreeNodeVm {
  node: MapaNodo;
  children: TreeNodeVm[];
  elementos: MapaElemento[];
  visible: boolean;
  hiddenElementCount: number;
}

interface DeletedFolderVm {
  elementos: MapaElemento[];
  visible: boolean;
}

export interface TreeNodeVisibilityChange {
  node: MapaNodo;
  visible: boolean;
}

export interface TreeElementoVisibilityChange {
  elemento: MapaElemento;
  visible: boolean;
}

export interface TreeCreateNodeRequest {
  parent: MapaNodo | null;
  tipo: MapaNodo['tipoNodo'];
}

export interface TreeDrawElementRequest {
  node: MapaNodo;
  geomTipo: MapaGeomTipo;
}

type ContextKind = 'node' | 'element' | null;

@Component({
  selector: 'app-mapa-tree',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './mapa-tree.component.html',
  styleUrl: './mapa-tree.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapaTreeComponent implements OnChanges {
  readonly DELETED_FOLDER_ID = -1;

  @ViewChild('treeScroll') treeScroll?: ElementRef<HTMLDivElement>;

  @Input() nodos: MapaNodo[] = [];
  @Input() elementos: MapaElemento[] = [];
  @Input() deletedElementos: MapaElemento[] = [];
  @Input() tipos: MapaTipoElemento[] = [];
  @Input() selectedNodoId: number | null = null;
  @Input() selectedElementoId: number | null = null;
  @Input() searchValue = '';
  @Input() hiddenNodeIds: number[] = [];
  @Input() hiddenElementoIds: number[] = [];
  @Input() deletedElementsVisible = false;

  @Output() nodoSelected = new EventEmitter<MapaNodo | null>();
  @Output() elementoSelected = new EventEmitter<MapaElemento>();
  @Output() nodeVisibilityChange = new EventEmitter<TreeNodeVisibilityChange>();
  @Output() elementoVisibilityChange = new EventEmitter<TreeElementoVisibilityChange>();
  @Output() createNodeRequested = new EventEmitter<TreeCreateNodeRequest>();
  @Output() editNodeRequested = new EventEmitter<MapaNodo>();
  @Output() auditNodeRequested = new EventEmitter<MapaNodo>();
  @Output() deleteNodeRequested = new EventEmitter<MapaNodo>();
  @Output() drawElementRequested = new EventEmitter<TreeDrawElementRequest>();
  @Output() centerElementoRequested = new EventEmitter<MapaElemento>();
  @Output() editDataElementoRequested = new EventEmitter<MapaElemento>();
  @Output() auditElementoRequested = new EventEmitter<MapaElemento>();
  @Output() editGeometryElementoRequested = new EventEmitter<MapaElemento>();
  @Output() deleteElementoRequested = new EventEmitter<MapaElemento>();
  @Output() restoreDeletedElementoRequested = new EventEmitter<MapaElemento>();
  @Output() deletedElementsVisibilityChange = new EventEmitter<boolean>();

  readonly expandedIds = signal<number[]>([]);
  readonly contextVisible = signal(false);
  readonly contextX = signal(0);
  readonly contextY = signal(0);
  readonly contextKind = signal<ContextKind>(null);
  readonly contextNode = signal<MapaNodo | null>(null);
  readonly contextElemento = signal<MapaElemento | null>(null);

  private readonly sessionStore = inject(SessionStore);

  readonly editarElemento = computed(() =>
    this.sessionStore.hasCompanyPrivilege('eem_red_red')
  );

  tree: TreeNodeVm[] = [];
  deletedFolder: DeletedFolderVm = { elementos: [], visible: false };

  performanceMode = false;
  performanceNotice = '';

  private readonly TREE_PERFORMANCE_THRESHOLD = 2500;
  private readonly TREE_LIMIT_NO_SEARCH = 2500;
  private readonly TREE_LIMIT_SEARCH = 1500;
  private readonly MAX_ELEMENTS_PER_NODE = 150;

  private treeElementos: MapaElemento[] = [];
  private treeDeletedElementos: MapaElemento[] = [];
  private hiddenNodeSet = new Set<number>();
  private hiddenElementoSet = new Set<number>();
  private tipoMap = new Map<number, MapaTipoElemento>();
  private pendingScrollToSelection = false;

  ngOnChanges(changes: SimpleChanges): void {
    const nodosChanged = !!changes['nodos'];
    const searchChanged = !!changes['searchValue'];
    const selectedNodoChanged = !!changes['selectedNodoId'];
    const selectedElementoChanged = !!changes['selectedElementoId'];
    const deletedChanged = !!changes['deletedElementos'];

    this.hiddenNodeSet = new Set(this.hiddenNodeIds);
    this.hiddenElementoSet = new Set(this.hiddenElementoIds);
    this.tipoMap = new Map(this.tipos.map((t) => [t.idGeoTipoElemento, t]));
    this.performanceMode = this.elementos.length >= this.TREE_PERFORMANCE_THRESHOLD;
    this.treeElementos = this.selectElementosForTree();
    this.treeDeletedElementos = this.selectDeletedElementosForTree();

    if (nodosChanged) {
      this.pruneExpandedIds();
    }

    this.rebuildTree();
    this.rebuildDeletedFolder();

    if (nodosChanged) {
      this.ensureRootNodesExpanded();
    }

    if (selectedNodoChanged || selectedElementoChanged || (searchChanged && (this.selectedNodoId != null || this.selectedElementoId != null))) {
      this.ensureSelectionPathExpanded();
    }

    if (deletedChanged && this.deletedFolder.elementos.length && this.deletedElementsVisible) {
      this.ensureDeletedFolderExpanded();
    }

    if (searchChanged || selectedNodoChanged || selectedElementoChanged) {
      this.requestScrollSelectionIntoView();
    }
  }

  get hasAnyTreeData(): boolean {
    return this.nodos.length > 0 || this.treeElementos.length > 0 || this.deletedElementos.length > 0;
  }

  get hasVisibleTreeData(): boolean {
    return this.tree.length > 0 || this.deletedFolder.visible;
  }

  get hasDeletedFolder(): boolean {
    return this.deletedFolder.elementos.length > 0;
  }

  get deletedFolderCountLabel(): string {
    return `${this.deletedFolder.elementos.length}`;
  }

  selectAll() {
    this.nodoSelected.emit(null);
    this.expandVisibleBranches();
  }

  expandAll() {
    this.expandVisibleBranches();
    if (this.hasDeletedFolder) {
      this.ensureDeletedFolderExpanded();
    }
  }

  collapseAll() {
    this.expandedIds.set([]);
  }

  createRootNode(tipo: MapaNodo['tipoNodo']) {
    this.createNodeRequested.emit({ parent: null, tipo });
  }

  toggleExpanded(nodeId: number, event?: Event) {
    event?.stopPropagation();

    const current = new Set(this.expandedIds());
    if (current.has(nodeId)) {
      current.delete(nodeId);
    } else {
      current.add(nodeId);
    }

    this.expandedIds.set([...current]);
  }

  toggleDeletedFolderExpanded(event?: Event) {
    this.toggleExpanded(this.DELETED_FOLDER_ID, event);
  }

  isExpanded(node: MapaNodo): boolean {
    return this.expandedIds().includes(node.idRedNodo);
  }

  isDeletedFolderExpanded(): boolean {
    return this.expandedIds().includes(this.DELETED_FOLDER_ID);
  }

  previewShapeClassForNode(node: MapaNodo): string {
    switch (node.tipoNodo) {
      case 'carpeta':
        return 'is-folder';
      case 'zona':
        return 'is-zone';
      case 'sitio':
        return 'is-site';
      case 'nodo_fisico':
        return 'is-physical-node';
      default:
        return 'is-folder';
    }
  }

  tipoDeElemento(elemento: MapaElemento): MapaTipoElemento | null {
    return this.tipoMap.get(elemento.idGeoTipoElementoFk) ?? null;
  }

  visualDeElemento(elemento: MapaElemento): MapaItemVisualPreview {
    return resolveMapaElementoVisual(elemento, this.tipoDeElemento(elemento));
  }

  previewShapeClassForElemento(elemento: MapaElemento): string {
    return previewShapeClassForVisual(this.visualDeElemento(elemento));
  }

  previewStyleForElemento(elemento: MapaElemento): Record<string, string> {
    return previewStyleForVisual(this.visualDeElemento(elemento));
  }

  previewMaterialFamilyForElemento(elemento: MapaElemento): string {
    return previewMaterialFamilyForVisual(this.visualDeElemento(elemento));
  }

  previewMaterialGlyphForElemento(elemento: MapaElemento): string {
    return previewMaterialGlyphForVisual(this.visualDeElemento(elemento));
  }

  previewClassForElemento(elemento: MapaElemento): string {
    return previewClassForVisual(this.visualDeElemento(elemento));
  }

  previewImageUrlForElemento(elemento: MapaElemento): string {
    return previewImageUrlForVisual(this.visualDeElemento(elemento));
  }

  showMaterialPreviewForElemento(elemento: MapaElemento): boolean {
    return showMaterialPreviewForVisual(this.visualDeElemento(elemento));
  }

  showClassPreviewForElemento(elemento: MapaElemento): boolean {
    return showClassPreviewForVisual(this.visualDeElemento(elemento));
  }

  showUrlPreviewForElemento(elemento: MapaElemento): boolean {
    return showUrlPreviewForVisual(this.visualDeElemento(elemento));
  }

  nodeOverflowLabel(item: TreeNodeVm): string {
    const hidden = Math.max(0, item.hiddenElementCount || 0);
    return `+${hidden} elemento(s) no listados para proteger el rendimiento`;
  }

  isNodeVisible(node: MapaNodo): boolean {
    return !isNodeHidden(node.idRedNodo, this.nodos, this.hiddenNodeIds);
  }

  isElementoVisible(elemento: MapaElemento): boolean {
    return (
      !this.hiddenElementoSet.has(elemento.idGeoElemento) &&
      !isNodeHidden(elemento.idRedNodoFk, this.nodos, this.hiddenNodeIds)
    );
  }

  isNodeIndeterminate(node: MapaNodo): boolean {
    if (!this.isNodeVisible(node)) return false;

    const branchNodeIds = getBranchNodeIds(node.idRedNodo, this.nodos);
    const hasHiddenDescendantNode = [...branchNodeIds].some(
      (id) => id !== node.idRedNodo && this.hiddenNodeSet.has(id)
    );

    if (hasHiddenDescendantNode) {
      return true;
    }

    for (const elemento of [...this.elementos, ...this.deletedElementos]) {
      if (branchNodeIds.has(elemento.idRedNodoFk) && this.hiddenElementoSet.has(elemento.idGeoElemento)) {
        return true;
      }
    }

    return false;
  }

  isDeletedElement(elemento: MapaElemento | null | undefined): boolean {
    return !!elemento?.fecFin;
  }

  onNodeClick(node: MapaNodo, event?: MouseEvent) {
    event?.stopPropagation();
    this.nodoSelected.emit(node);
  }

  onElementoClick(elemento: MapaElemento, event?: MouseEvent) {
    event?.stopPropagation();
    this.elementoSelected.emit(elemento);
    this.centerElementoRequested.emit(elemento);
  }

  onToggleNode(node: MapaNodo, event: Event) {
    event.stopPropagation();
    const checked = (event.target as HTMLInputElement).checked;
    this.nodeVisibilityChange.emit({ node, visible: checked });
  }

  onToggleElemento(elemento: MapaElemento, event: Event) {
    event.stopPropagation();
    const checked = (event.target as HTMLInputElement).checked;
    this.elementoVisibilityChange.emit({ elemento, visible: checked });
  }

  onToggleDeletedElements(event: Event) {
    event.stopPropagation();
    const checked = (event.target as HTMLInputElement).checked;
    this.deletedElementsVisibilityChange.emit(checked);

    if (checked) {
      this.ensureDeletedFolderExpanded();
    }
  }

  openNodeContext(node: MapaNodo, event: MouseEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.contextKind.set('node');
    this.contextNode.set(node);
    this.contextElemento.set(null);
    this.contextX.set(event.clientX);
    this.contextY.set(event.clientY);
    this.contextVisible.set(true);
  }

  openElementoContext(elemento: MapaElemento, event: MouseEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.contextKind.set('element');
    this.contextElemento.set(elemento);
    this.contextNode.set(null);
    this.contextX.set(event.clientX);
    this.contextY.set(event.clientY);
    this.contextVisible.set(true);
  }

  closeContext() {
    this.contextVisible.set(false);
  }

  trackByNode = (_: number, item: TreeNodeVm) => item.node.idRedNodo;
  trackByElemento = (_: number, item: MapaElemento) => item.idGeoElemento;

  private selectElementosForTree(): MapaElemento[] {
    let source = this.elementos.slice();

    if (!this.performanceMode) {
      this.performanceNotice = '';
      return source;
    }

    const focusNodeId = this.resolveFocusNodeId();
    if (focusNodeId != null) {
      const branchIds = getBranchNodeIds(focusNodeId, this.nodos);
      source = source.filter((el) => branchIds.has(el.idRedNodoFk));
    }

    const limit = this.TREE_LIMIT_NO_SEARCH;

    if (source.length <= limit) {
      this.performanceNotice = '';
      return source;
    }

    const trimmed = source.slice(0, limit);
    const selected = this.selectedElementoId != null
      ? source.find((el) => el.idGeoElemento === this.selectedElementoId) ?? null
      : null;

    if (
      selected &&
      !trimmed.some((el) => el.idGeoElemento === selected.idGeoElemento)
    ) {
      trimmed[trimmed.length - 1] = selected;
    }

    this.performanceNotice = '';
    return trimmed;
  }

  private selectDeletedElementosForTree(): MapaElemento[] {
    const source = this.deletedElementos.filter((item) => this.isDeletedElement(item));

    return source
      .slice()
      .sort((a, b) => {
        return (
          Number(a.ordenDibujo ?? 0) - Number(b.ordenDibujo ?? 0) ||
          a.nombre.localeCompare(b.nombre) ||
          a.idGeoElemento - b.idGeoElemento
        );
      });
  }

  private resolveFocusNodeId(): number | null {
    if (this.selectedNodoId != null) {
      return this.selectedNodoId;
    }

    if (this.selectedElementoId != null) {
      const selected =
        this.elementos.find((el) => el.idGeoElemento === this.selectedElementoId) ??
        this.deletedElementos.find((el) => el.idGeoElemento === this.selectedElementoId);
      if (selected) {
        return selected.idRedNodoFk;
      }
    }

    return null;
  }

  private rebuildTree() {
    const byParent = new Map<number | null, MapaNodo[]>();
    const elementosByNodo = new Map<number, MapaElemento[]>();
    const allNodeIds = new Set(this.nodos.map((n) => n.idRedNodo));
    const q = '';

    for (const n of this.nodos) {
      const rawParent = n.idRedNodoPadreFk ?? null;
      const parentId = rawParent != null && allNodeIds.has(rawParent) ? rawParent : null;
      const arr = byParent.get(parentId) ?? [];
      arr.push(n);
      byParent.set(parentId, arr);
    }

    for (const el of this.treeElementos) {
      const arr = elementosByNodo.get(el.idRedNodoFk) ?? [];
      arr.push(el);
      elementosByNodo.set(el.idRedNodoFk, arr);
    }

    let roots = (byParent.get(null) ?? []).slice().sort(sortNodes);

    if (!roots.length && this.nodos.length > 0) {
      const minNivel = Math.min(...this.nodos.map((n) => n.nivel ?? 0));
      roots = this.nodos
        .filter((n) => (n.nivel ?? 0) === minNivel)
        .slice()
        .sort(sortNodes);
    }

    const build = (node: MapaNodo): TreeNodeVm => {
      const rawChildren = (byParent.get(node.idRedNodo) ?? []).slice().sort(sortNodes);
      const children = rawChildren.map(build);

      const rawElementos = (elementosByNodo.get(node.idRedNodo) ?? [])
        .slice()
        .sort((a, b) => {
          return (
            Number(a.ordenDibujo ?? 0) - Number(b.ordenDibujo ?? 0) ||
            a.nombre.localeCompare(b.nombre) ||
            a.idGeoElemento - b.idGeoElemento
          );
        });

      const elementLimit =
        this.performanceMode && !q ? this.MAX_ELEMENTS_PER_NODE : Number.MAX_SAFE_INTEGER;

      const elementos =
        rawElementos.length > elementLimit
          ? rawElementos.slice(0, elementLimit)
          : rawElementos;

      const hiddenElementCount = Math.max(0, rawElementos.length - elementos.length);

      const visible = true;

      return {
        node,
        children,
        elementos,
        visible,
        hiddenElementCount,
      };
    };

    this.tree = roots.map(build).filter((n) => n.visible);
  }

  private rebuildDeletedFolder() {
    const elementos = this.treeDeletedElementos;

    this.deletedFolder = {
      elementos,
      visible: elementos.length > 0,
    };
  }

  private pruneExpandedIds() {
    const validIds = new Set(this.nodos.map((n) => n.idRedNodo));
    validIds.add(this.DELETED_FOLDER_ID);
    const next = this.expandedIds().filter((id) => validIds.has(id));

    if (next.length !== this.expandedIds().length) {
      this.expandedIds.set(next);
    }
  }

  private ensureRootNodesExpanded() {
    const ids = getRootNodeIds(this.nodos);
    if (!ids.length) return;

    const current = new Set(this.expandedIds());
    let changed = false;

    for (const id of ids) {
      if (!current.has(id)) {
        current.add(id);
        changed = true;
      }
    }

    if (changed) {
      this.expandedIds.set([...current]);
    }
  }

  private ensureSelectionPathExpanded() {
    const current = new Set(this.expandedIds());
    let changed = false;

    if (this.selectedNodoId != null) {
      for (const id of getAncestorNodeIds(this.selectedNodoId, this.nodos)) {
        if (!current.has(id)) {
          current.add(id);
          changed = true;
        }
      }
      if (!current.has(this.selectedNodoId)) {
        current.add(this.selectedNodoId);
        changed = true;
      }
    }

    if (this.selectedElementoId != null) {
      const el =
        this.elementos.find((x) => x.idGeoElemento === this.selectedElementoId) ??
        this.deletedElementos.find((x) => x.idGeoElemento === this.selectedElementoId);
      if (el) {
        for (const id of getAncestorNodeIds(el.idRedNodoFk, this.nodos)) {
          if (!current.has(id)) {
            current.add(id);
            changed = true;
          }
        }
        if (!current.has(el.idRedNodoFk)) {
          current.add(el.idRedNodoFk);
          changed = true;
        }

        if (this.isDeletedElement(el)) {
          current.add(this.DELETED_FOLDER_ID);
          changed = true;
        }
      }
    }

    if (changed) {
      this.expandedIds.set([...current]);
    }
  }

  private ensureDeletedFolderExpanded() {
    const current = new Set(this.expandedIds());
    if (!current.has(this.DELETED_FOLDER_ID)) {
      current.add(this.DELETED_FOLDER_ID);
      this.expandedIds.set([...current]);
    }
  }

  private expandVisibleBranches() {
    const visibleIds = new Set<number>();

    const walk = (items: TreeNodeVm[]) => {
      for (const item of items) {
        visibleIds.add(item.node.idRedNodo);
        if (item.children.length) {
          walk(item.children);
        }
      }
    };

    walk(this.tree);

    if (this.deletedFolder.elementos.length) {
      visibleIds.add(this.DELETED_FOLDER_ID);
    }

    this.expandedIds.set([...visibleIds]);
  }

  private matchesNode(node: MapaNodo): boolean {
    const q = this.searchValue.trim().toLowerCase();
    if (!q) return true;

    return [
      node.nodo,
      node.descripcion ?? '',
      node.codigo ?? '',
      node.tipoNodo,
    ].some((v) => (v || '').toLowerCase().includes(q));
  }

  private matchesElementoWithQuery(elemento: MapaElemento, q: string): boolean {
    return [
      elemento.nombre,
      elemento.descripcion ?? '',
      elemento.codigo ?? '',
      elemento.etiqueta ?? '',
      elemento.observacion ?? '',
      elemento.estado ?? '',
    ].some((v) => (v || '').toLowerCase().includes(q));
  }

  private requestScrollSelectionIntoView() {
    if (this.pendingScrollToSelection) {
      return;
    }

    this.pendingScrollToSelection = true;

    queueMicrotask(() => {
      requestAnimationFrame(() => {
        this.pendingScrollToSelection = false;
        this.scrollSelectionIntoView();
      });
    });
  }

  private scrollSelectionIntoView() {
    const host = this.treeScroll?.nativeElement;
    if (!host) {
      return;
    }

    const selector =
      this.selectedElementoId != null
        ? `.element-row[data-element-id="${this.selectedElementoId}"]`
        : this.selectedNodoId != null
          ? `.node-row[data-node-id="${this.selectedNodoId}"]`
          : null;

    if (!selector) {
      return;
    }

    const target = host.querySelector<HTMLElement>(selector);
    target?.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'nearest',
    });
  }
}
