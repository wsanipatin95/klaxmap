import { Component, inject, signal, computed, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AccesoService } from '../../../core/services/acceso.service';
import { NocApi, Device } from '../services/noc-api';
import { cpuColor } from '../shared/charts';
import { TableSort } from '../shared/table-sort';

@Component({
  selector: 'app-equipos',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="tools">
      @if (showBack()) { <button class="btn ghost sm" (click)="back()" title="Volver">← Atrás</button> }
      <input class="inp" style="min-width:240px" placeholder="🔍 Buscar equipo, IP, zona..." [(ngModel)]="q" />
      <span class="chip" [class.on]="filter()==='all'" (click)="filter.set('all')">Todos</span>
      <span class="chip" [class.on]="filter()==='core'" (click)="filter.set('core')">Core</span>
      <span class="chip" [class.on]="filter()==='borde'" (click)="filter.set('borde')">Borde</span>
      <span class="chip" [class.on]="filter()==='down'" (click)="filter.set('down')">Down</span>
      <button class="btn" style="margin-left:auto" (click)="nuevo()">+ Nuevo equipo</button>
    </div>

    <div class="panel">
      <table>
        <thead><tr>
          <th class="srt" (click)="sort.by('nombre')">Nombre NOC{{ sort.arrow('nombre') }}</th>
          <th class="srt" (click)="sort.by('vendor')">Vendor{{ sort.arrow('vendor') }}</th>
          <th class="srt" (click)="sort.by('zona')">Zona{{ sort.arrow('zona') }}</th>
          <th class="srt" (click)="sort.by('tipo')">Tipo{{ sort.arrow('tipo') }}</th>
          <th class="srt" (click)="sort.by('ip')">IP{{ sort.arrow('ip') }}</th>
          <th class="srt" (click)="sort.by('estado')">Estado{{ sort.arrow('estado') }}</th>
          <th class="srt" (click)="sort.by('cpu')">CPU{{ sort.arrow('cpu') }}</th>
          <th class="srt" (click)="sort.by('ping')">Ping{{ sort.arrow('ping') }}</th>
          @if (esSupervisor()) { <th style="width:96px;text-align:right">Acciones</th> }
        </tr></thead>
        <tbody>
          @for (d of rows(); track d.id) {
            <tr class="clk" (click)="open(d)">
              <td><b>{{ d.name }}</b></td>
              <td>{{ d.vendor }}</td>
              <td>{{ d.zone || '—' }}</td>
              <td>@if (d.device_type==='core') { <span class="badge b-ack">CORE</span> } @else { {{ d.device_type }} }</td>
              <td class="mono">{{ d.ip_address }}</td>
              <td [innerHTML]="badge(d.status)"></td>
              <td>@if (d.status==='up' && d.snmp_enabled && d.cpu_percent!=null) { <b [style.color]="cpuColor(d.cpu_percent)">{{ d.cpu_percent }}%</b> } @else { <span style="color:var(--muted)" title="Requiere SNMP habilitado para leer CPU real">—</span> }</td>
              <td>@if (d.ping_ms!=null) { {{ d.ping_ms }} ms } @else { <span style="color:var(--red)">timeout</span> }</td>
              @if (esSupervisor()) {
                <td style="text-align:right;white-space:nowrap" (click)="$event.stopPropagation()">
                  <button class="btn ghost sm" title="Editar equipo" (click)="editar(d)">✎</button>
                  <button class="btn ghost sm" style="margin-left:4px;color:var(--red)" title="Eliminar equipo" (click)="pedirBorrar(d)">🗑</button>
                </td>
              }
            </tr>
          } @empty {
            <tr><td [attr.colspan]="esSupervisor() ? 9 : 8" style="text-align:center;color:var(--muted);padding:34px">
              {{ loaded() ? 'No hay equipos. Usa "+ Nuevo equipo".' : 'Cargando… (si no aparece, revisa que el backend corra en :8081).' }}
            </td></tr>
          }
        </tbody>
      </table>
    </div>

    @if (showAdd()) {
      <div class="overlay on" (click)="showAdd.set(false)"></div>
      <div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;z-index:60" (click)="showAdd.set(false)">
        <div class="panel" style="width:520px;max-width:92vw" (click)="$event.stopPropagation()">
          <div class="ph">{{ f.id ? 'Editar equipo' : 'Agregar equipo' }}</div>
          <div class="pb" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div style="grid-column:1/3"><label class="k">Nombre NOC</label><input class="inp" style="width:100%" [(ngModel)]="f.name"></div>
            <div><label class="k">Vendor</label><input class="inp" style="width:100%" [(ngModel)]="f.vendor"></div>
            <div><label class="k">Modelo</label><input class="inp" style="width:100%" [(ngModel)]="f.model"></div>
            <div><label class="k">Tipo</label>
              <select class="inp" style="width:100%" [(ngModel)]="f.device_type"><option value="borde">Borde</option><option value="core">Core</option><option value="olt">OLT</option></select></div>
            <div><label class="k">Zona</label><input class="inp" style="width:100%" [(ngModel)]="f.zone"></div>
            <div><label class="k">IP</label><input class="inp" style="width:100%" [(ngModel)]="f.ip_address"></div>
            <div><label class="k">Community SNMP</label><input class="inp" style="width:100%" [(ngModel)]="f.snmp_community"></div>
            <div style="grid-column:1/3;display:flex;align-items:center;gap:8px">
              <input type="checkbox" [(ngModel)]="f.snmp_enabled"> <span>Habilitar SNMP (CPU/memoria/tráfico reales)</span></div>

            @if (f.device_type === 'olt') {
              <div style="grid-column:1/3;border-top:1px dashed var(--border);padding-top:10px;color:var(--muted);font-size:12px">
                Conexión de la OLT (para monitorear ONUs). Al guardar aparece en <b>Clientes / ONUs</b> para sacar tarjetas.
              </div>
              <div><label class="k">Telnet usuario</label><input class="inp" style="width:100%" [(ngModel)]="f.telnet_user"></div>
              <div><label class="k">Telnet clave</label><input type="password" class="inp" style="width:100%" [(ngModel)]="f.telnet_pass"></div>
              <div><label class="k">Telnet puerto</label><input type="number" class="inp" style="width:100%" [(ngModel)]="f.telnet_port" placeholder="23"></div>
              <div><label class="k">SNMP puerto</label><input type="number" class="inp" style="width:100%" [(ngModel)]="f.snmp_port" placeholder="161"></div>
              <div style="display:flex;align-items:center;gap:8px;padding-top:20px"><input type="checkbox" [(ngModel)]="f.snmp_poll_enabled"> <span>Barrido SNMP automático</span></div>
              <div><label class="k">Intervalo barrido (seg)</label><input type="number" class="inp" style="width:100%" [(ngModel)]="f.snmp_poll_seconds" placeholder="300"></div>
            }
          </div>
          <div class="ph" style="border-top:1px solid var(--border);border-bottom:none;justify-content:flex-end">
            <button class="btn ghost" (click)="showAdd.set(false)">Cancelar</button>
            <button class="btn" (click)="save()">Guardar</button>
          </div>
        </div>
      </div>
    }

    @if (testing()) {
      <div class="overlay on" style="z-index:90"></div>
      <div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;z-index:91">
        <div class="panel" style="width:380px;text-align:center">
          <div class="pb" style="padding:32px 24px">
            <div style="font-size:32px;margin-bottom:14px">⏳</div>
            <div style="font-weight:600;font-size:15px;line-height:1.7">Probando conexión Telnet<br>Espere Por Favor</div>
          </div>
        </div>
      </div>
    }
    @if (saveErr()) {
      <div class="overlay on" style="z-index:96" (click)="saveErr.set('')"></div>
      <div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;z-index:97" (click)="saveErr.set('')">
        <div class="panel" style="width:440px;text-align:center" (click)="$event.stopPropagation()">
          <div class="pb" style="padding:28px 24px">
            <div style="font-size:30px;margin-bottom:12px">⚠️</div>
            <div style="font-weight:600;font-size:14px;line-height:1.7;color:var(--red)">No se pudo completar la operación</div>
            <div style="font-size:12.5px;color:var(--muted);line-height:1.6;margin-top:8px">{{ saveErr() }}</div>
            <div style="display:flex;justify-content:center;margin-top:16px">
              <button class="btn" (click)="saveErr.set('')">Cerrar</button>
            </div>
          </div>
        </div>
      </div>
    }
    @if (borrar()) {
      <div class="overlay on" style="z-index:94" (click)="borrar.set(null)"></div>
      <div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;z-index:95" (click)="borrar.set(null)">
        <div class="panel" style="width:420px;text-align:center" (click)="$event.stopPropagation()">
          <div class="pb" style="padding:28px 24px">
            <div style="font-size:30px;margin-bottom:12px">🗑</div>
            <div style="font-weight:600;font-size:15px;line-height:1.7">Eliminar equipo</div>
            <div style="font-size:12.5px;color:var(--muted);line-height:1.6;margin-top:8px">
              Se eliminará <b>{{ borrar()?.name }}</b> ({{ borrar()?.ip_address }}) del <b>ERP y del NOC</b>.
              Esta acción no se puede deshacer.
            </div>
            <div style="display:flex;gap:10px;justify-content:center;margin-top:16px">
              <button class="btn ghost" (click)="borrar.set(null)">Cancelar</button>
              <button class="btn" style="background:var(--red);border-color:var(--red)" (click)="confirmarBorrar()">Eliminar</button>
            </div>
          </div>
        </div>
      </div>
    }
    @if (dupErr()) {
      <div class="overlay on" style="z-index:92" (click)="dupErr.set(false)"></div>
      <div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;z-index:93" (click)="dupErr.set(false)">
        <div class="panel" style="width:400px;text-align:center" (click)="$event.stopPropagation()">
          <div class="pb" style="padding:28px 24px">
            <div style="font-size:30px;margin-bottom:12px">⚠️</div>
            <div style="font-weight:600;font-size:15px;line-height:1.7">Equipo Ya Agregado</div>
            <div style="font-size:12.5px;color:var(--muted);line-height:1.6;margin-top:8px">
              Ya existe un equipo registrado con la IP <b>{{ f.ip_address }}</b> y el puerto <b>{{ f.snmp_port || 161 }}</b>.
            </div>
            <div style="display:flex;justify-content:center;margin-top:16px">
              <button class="btn" (click)="dupErr.set(false)">Entendido</button>
            </div>
          </div>
        </div>
      </div>
    }
    @if (testErr()) {
      <div class="overlay on" style="z-index:90" (click)="testErr.set('')"></div>
      <div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;z-index:91" (click)="testErr.set('')">
        <div class="panel" style="width:440px;text-align:center" (click)="$event.stopPropagation()">
          <div class="pb" style="padding:28px 24px">
            <div style="font-size:30px;margin-bottom:12px">⚠️</div>
            <div style="font-weight:600;font-size:14px;line-height:1.7;color:var(--red)">Sin conexión Telnet a la OLT</div>
            <div style="font-size:12.5px;color:var(--muted);line-height:1.6;margin-top:8px">{{ testErr() }}</div>
            <div style="display:flex;gap:10px;justify-content:center;margin-top:16px">
              <button class="btn ghost" (click)="testErr.set('')">Corregir</button>
              <button class="btn" (click)="doSave()">Guardar igual</button>
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class Equipos implements OnDestroy {
  private api = inject(NocApi);
  private acceso = inject(AccesoService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private timer: any;
  cpuColor = cpuColor;
  showBack = signal(this.route.snapshot.queryParamMap.get('back') === '1');
  back() { history.back(); }

  devices = signal<Device[]>([]);
  loaded = signal(false);
  q = '';
  filter = signal<'all' | 'core' | 'borde' | 'down'>('all');
  showAdd = signal(false);
  testing = signal(false);
  testErr = signal('');
  dupErr = signal(false);       // equipo repetido (misma IP + puerto)
  saveErr = signal('');         // error al guardar/eliminar (NO es un fallo de Telnet)
  borrar = signal<Device | null>(null);   // equipo pendiente de confirmar borrado

  /**
   * Editar y eliminar equipos quedan reservados a nivel supervisor:
   * administrador de la organización o privilegio de empresa NOC_EQUIPOS_ADMIN.
   *
   * OJO: esto solo OCULTA los botones. El control real tiene que estar en el
   * servidor (ver nota al pie de este archivo); el front no es una barrera de
   * seguridad, solo evita que un operador se equivoque.
   */
  esSupervisor = computed(() => this.acceso.esSupervisorEquipos());
  f: any = { device_type: 'borde', snmp_community: 'public', snmp_enabled: false, snmp_poll_enabled: true, snmp_poll_seconds: 300 };

  constructor() {
    this.load();
    // Auto-refresco cada 15s (la pantalla se mantiene viva).
    this.timer = setInterval(() => this.load(), 15000);
  }

  ngOnDestroy(): void { clearInterval(this.timer); }

  load() {
    this.api.devices().subscribe({
      next: (d) => { this.devices.set(d); this.loaded.set(true); },
      error: () => this.loaded.set(true),
    });
  }

  sort = new TableSort<Device>({
    nombre: (d) => d.name,
    vendor: (d) => d.vendor,
    zona: (d) => d.zone,
    tipo: (d) => d.device_type,
    ip: (d) => d.ip_address,
    estado: (d) => d.status,
    cpu: (d) => d.cpu_percent,
    ping: (d) => d.ping_ms,
  }, 'nombre');

  view(): Device[] {
    const q = this.q.toLowerCase().trim();
    return this.devices().filter((d) => {
      if (this.filter() === 'core' && d.device_type !== 'core') return false;
      if (this.filter() === 'borde' && d.device_type !== 'borde') return false;
      if (this.filter() === 'down' && d.status === 'up') return false;
      if (q && !(`${d.name} ${d.ip_address} ${d.zone}`.toLowerCase().includes(q))) return false;
      return true;
    });
  }

  /** Lista filtrada + ordenada por la cabecera elegida. */
  rows(): Device[] { return this.sort.apply(this.view()); }

  badge(s: string): string {
    if (s === 'up') return '<span class="badge b-up">UP</span>';
    if (s === 'down') return '<span class="badge b-down">DOWN</span>';
    return '<span class="badge b-maint">UNKNOWN</span>';
  }

  open(d: Device) { this.router.navigate(['/app/monitoreo/equipos', d.id]); }

  /** Abre el mismo modal del alta, precargado. El id en 'f' marca que es edición. */
  editar(d: Device) {
    this.f = { ...(d as any) };
    this.testErr.set(''); this.dupErr.set(false); this.saveErr.set('');
    this.showAdd.set(true);
  }

  pedirBorrar(d: Device) { this.borrar.set(d); }

  confirmarBorrar() {
    const d = this.borrar();
    if (!d) return;
    this.api.deleteDevice(d.id).subscribe({
      next: () => { this.borrar.set(null); this.load(); },
      error: (e: any) => { this.borrar.set(null); this.saveErr.set(e?.message || 'No se pudo eliminar el equipo.'); },
    });
  }

  nuevo() {
    this.f = { device_type: 'borde', snmp_community: 'public', snmp_enabled: false, snmp_poll_enabled: true, snmp_poll_seconds: 300 };
    this.testErr.set(''); this.dupErr.set(false); this.saveErr.set('');
    this.showAdd.set(true);
  }

  /** ¿Ya hay un equipo cargado con esta misma IP y puerto SNMP? (chequeo inmediato, sin ir al server) */
  private esDuplicado(): boolean {
    const ip = (this.f.ip_address || '').trim();
    if (!ip) return false;
    const port = Number(this.f.snmp_port) || 161;
    return this.devices().some((d: any) =>
      (d.ip_address || '').trim() === ip && (Number(d.snmp_port) || 161) === port && d.id !== this.f.id);
  }

  save() {
    if (!this.f.name) return;
    // Duplicado por IP + puerto: se corta acá, antes incluso de probar Telnet.
    if (this.esDuplicado()) { this.dupErr.set(true); return; }
    // Si es OLT con credenciales Telnet, validar la conexión antes de guardar.
    if (this.f.device_type === 'olt' && this.f.telnet_user) {
      this.testing.set(true); this.testErr.set('');
      this.api.testTelnet({ host: this.f.ip_address, port: this.f.telnet_port || 23, user: this.f.telnet_user, pass: this.f.telnet_pass })
        .subscribe({
          next: (r: any) => {
            this.testing.set(false);
            if (r?.ok) this.doSave();
            else this.testErr.set(r?.error || 'No se pudo conectar por Telnet a la OLT.');
          },
          error: () => { this.testing.set(false); this.testErr.set('No se pudo probar la conexión Telnet.'); },
        });
    } else {
      this.doSave();
    }
  }

  doSave() {
    // Con id -> edición (PUT); sin id -> alta (POST). Ambos escriben en ERP y NOC.
    const req = this.f.id
      ? this.api.updateDevice(this.f.id, this.f)
      : this.api.createDevice(this.f);
    req.subscribe({
      next: () => { this.showAdd.set(false); this.testErr.set(''); this.load(); },
      // El backend valida lo mismo (IP + puerto). Si dos usuarios cargan a la vez, acá cae.
      error: (e: any) => {
        if (String(e?.message || '').includes('Ya Agregado')) { this.testErr.set(''); this.dupErr.set(true); }
        else { this.testErr.set(''); this.saveErr.set(e?.message || 'No se pudo guardar el equipo.'); }
      },
    });
  }
}
