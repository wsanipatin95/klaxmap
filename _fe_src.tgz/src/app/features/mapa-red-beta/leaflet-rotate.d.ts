declare module 'leaflet-rotate';
